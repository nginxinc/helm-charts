# WAF Policy Lifecycle Manager Helm Chart

This Helm chart deploys the WAF Policy Lifecycle Manager components for managing security policies through Kubernetes custom resources.

## Overview

The chart provides:
- **Policy Controller**: Kubernetes operator that watches and manages AppProtect custom resources
- **Compiler**: Compiles security policies and bundles via gRPC
- **SeaweedFS**: S3-compatible storage for compiled policy bundles

## Dependency Wait Image

The chart's dependency-wait init containers use a public image by default:

```yaml
dependencyWait:
  image:
    repository: curlimages/curl
    tag: "8.20.0"
    pullPolicy: IfNotPresent
```

This is the default chart behavior. If you do not want to pull that public image, override `dependencyWait.image.repository` and `dependencyWait.image.tag` with your own internal or mirrored image.

The compiler always runs a separate image-local init container to populate its shared App Protect volume; it does not use the dependency-wait image.

## Prerequisites

- Kubernetes Cluster
- Helm 3.7.0+ for chart rendering compatibility. The validation script keeps
  this legacy floor because a downstream runner still uses Helm 3.7.0; use a
  newer Helm if your installation flow or platform requires it.
- If you enable [Compiler CPU HPA](#compiler-cpu-hpa), the cluster must have a
  working resource metrics API such as `metrics-server`. The chart renders the
  HPA without it, but the HPA cannot evaluate CPU utilization or scale.
- If you enable [Compiler CPU HPA](#compiler-cpu-hpa), Kubernetes must be 1.23+
  because the chart renders `autoscaling/v2` for that opt-in feature.
- Nodes expected to host compiler pods should have roughly 4 vCPU of headroom at the shipped `compiler.maxConcurrent: 4` setting, or override `compiler.resources` for constrained dev/CI clusters.

## Custom Resource Definitions (CRDs)

This chart includes and automatically installs the following CRDs during initial installation:

- `appolicies.appprotect.f5.com`
- `aplogconfs.appprotect.f5.com`
- `apusersigs.appprotect.f5.com`
- `apsignatures.appprotect.f5.com`

**Important**: CRDs are only installed during `helm install`. They are **not** upgraded during `helm upgrade`. If you need to upgrade CRDs, you must apply them manually:

```bash
kubectl apply -f crds/
```


## Pull the Chart
1. Login to the registry
    ```
    helm registry login private-registry.nginx.com
    ```

1. Pull the chart
    ```
    helm pull oci://private-registry.nginx.com/nap/waf-policy-lifecycle-managment --version <release-version> --untar
    ```

1. Change your working directory to waf-policy-lifecycle-managment
    ```
    cd waf-policy-lifecycle-managment
    ```

### Basic Installation

```bash
helm install <release-name> .
```
Replace `<release-name>` with your desired release name.

### With Custom Values

```bash
helm install <release-name> . \
  --values custom-values.yaml
```

### Image Tags

The default image tags in `values.yaml` (e.g. `5.12.0` for `policyController.image.tag`,
`compiler.image.tag`, `seaweedfsOperatorConfig.seaweedfs.image.tag`)
are placeholders that point at the last published release. They are not synchronised
with the chart `version`/`appVersion` and will not match the `vX.Y.Z` tags that this
repository's CI publishes from `.next-version`.

When deploying a build produced by this repository, override the relevant image tags
explicitly, for example:

```bash
helm install <release-name> . \
  --set policyController.image.tag=vX.Y.Z \
  --set compiler.image.tag=vX.Y.Z
```

Or pass a values file that pins the tags to the build under test. Treat the defaults
in `values.yaml` as the contract for the latest published OCI chart, not as the tag
your CI just produced.


## Upgrade the Chart

### Compiler Capacity Check

Before upgrading, audit that `policyController.maxConcurrentCompilations <= compiler.maxConcurrent * compiler.replicas`. If the check does not pass, lower `policyController.maxConcurrentCompilations` or increase `compiler.maxConcurrent` and `compiler.replicas` before upgrading. The chart rejects a rendered configuration that exceeds the computed compiler capacity when both values are set explicitly. If `compiler.maxConcurrent` is empty, the compiler uses its built-in default and the chart skips this render-time guard because it cannot calculate capacity reliably.

In fixed-replica mode, `compiler.replicas=0` is not a supported pause configuration when controller dispatch is positive. The chart's default controller dependency-wait init container expects compiler endpoints before startup, and the controller cannot compile without a running compiler.

When [Compiler CPU HPA](#compiler-cpu-hpa) is enabled, plan maximum dispatch against `compiler.autoscaling.maxReplicas` instead of the fixed replica count.

### Upgrading CRDs

Helm does not upgrade CRDs during `helm upgrade`. If the chart version includes updated CRDs, you must manually apply them before upgrading:

```bash
kubectl apply -f crds/
```

Then proceed with the Helm upgrade:

```bash
helm upgrade <release-name> . --values custom-values.yaml
```

## Uninstall the Chart

```bash
helm uninstall <release-name>
```

**Note**: This will not delete:
- CRDs
- Persistent volumes (if using persistent storage)
- AppProtect custom resources

## Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| **Global Settings** | | |
| `namespace` | Target namespace | `""` (uses release namespace) |
| `imagePullSecrets` | List of image pull secret names to use for pulling container images | `[]` |
| `dockerConfigJson` | Docker config JSON for creating image pull secret | `""` |
| `dependencyWait.enabled` | When enabled (and seaweedfsOperatorConfig.enabled=true), add a policy-controller init container that waits for SeaweedFS S3 and compiler gRPC to be reachable | `true` |
| `dependencyWait.image.repository` | Init container image | `curlimages/curl` |
| `dependencyWait.image.tag` | Init container image tag | `8.20.0` |
| `dependencyWait.image.pullPolicy` | Init container image pull policy | `IfNotPresent` |
| `dependencyWait.timeoutSeconds` | Dependency wait timeout | `300` |
| **Policy Controller** | | |
| `policyController.replicas` | Number of controller replicas. Must stay `1`: the chart enforces a single-writer controller and rejects higher values. | `1` |
| `policyController.image.repository` | Controller image repository | `private-registry.nginx.com/nap/waf-policy-controller` |
| `policyController.image.tag` | Controller image tag | `5.16.1` |
| `policyController.image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `policyController.watchNamespace` | Namespaces to watch (comma-separated or empty for release namespace) | `""` |
| `policyController.s3.s3Endpoint` | Override S3 endpoint (auto-calculated if not set) | `""` |
| `policyController.s3.skipTlsVerify` | Skip TLS certificate verification (for testing with self-signed certificates) | `true` |
| `policyController.resources.requests.memory` | Memory request per policy-controller pod. See [Resource Profiles](#resource-profiles) for environment-specific overrides. | `128Mi` |
| `policyController.resources.requests.cpu` | CPU request per policy-controller pod. Raise this if you watch many namespaces or run a high reconcile volume. See [Resource Profiles](#resource-profiles) for environment-specific overrides. | `250m` |
| `policyController.resources.limits.cpu` | CPU limit for the policy-controller pod. Unset by default; add it only when platform policy requires an explicit bound. See [Resource Profiles](#resource-profiles). | _(unset)_ |
| `policyController.securityContext` | Container security context | See values.yaml |
| `policyController.maxConcurrentCompilations` | Maximum number of concurrent compilations sent to compiler. Keep this at or below `compiler.maxConcurrent * compiler.replicas`; see [Compilation Capacity Sizing](#compilation-capacity-sizing). | `4` |
| `policyController.compilerDNSRefreshInterval` | How often the controller forces a DNS re-resolution of the headless compiler Service so runtime scale-out reaches new pods without restarting. Values below `30s` are clamped to `30s`; set to `0` to disable. This fixes endpoint discovery, but you still need enough `policyController.maxConcurrentCompilations` to feed the added replicas. | `30s` |
| `policyController.env` | Additional environment variables | `[]` |
| `policyController.initContainers` | Additional init containers | `[]` |
| `policyController.processingTimeout` | Time after which a resource stuck in active processing is considered timed out | `10m` |
| `policyController.pendingTimeout` | Time after which a resource waiting in `pending` is considered timed out | `30m` |
| `policyController.apsignatures.latestAll` | Signature updates behavior: on initial create, the chart defaults to an empty `apsignatures` spec; set to `true` to create it with `latest` for all signature revisions. Existing `apsignatures` settings are always preserved. | `false` |
| **Compiler** | | |
| `compiler.replicas` | Fixed number of compiler replicas when autoscaling is disabled | `1` |
| `compiler.autoscaling.enabled` | Enable the CPU-based compiler HPA. Case-insensitive `true` enables it; case-insensitive `false` retains fixed-replica behavior, including when passed through `--set-string`. Other values fail rendering. | `false` |
| `compiler.autoscaling.minReplicas` | Minimum compiler replicas managed by the HPA. Must be at least `1`. | `1` |
| `compiler.autoscaling.maxReplicas` | Maximum compiler replicas managed by the HPA. Must be at least `compiler.autoscaling.minReplicas`. | `3` |
| `compiler.autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization percentage for the compiler HPA. Must be set and at least `1`. | `70` |
| `compiler.maxConcurrent` | Maximum number of concurrent compilations processed by the compiler service (passed as the compiler's `--max-concurrent` flag). Distinct from `policyController.maxConcurrentCompilations`. Set to empty to omit the flag and use the compiler's built-in default. | `4` |
| `compiler.grpc.port` | gRPC server port | `50051` |
| `compiler.health.port` | Health check HTTP port | `8080` |
| `compiler.image.repository` | Compiler image repository | `private-registry.nginx.com/nap/waf-compiler` |
| `compiler.image.tag` | Compiler image tag | `5.16.1` |
| `compiler.image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `compiler.resources.requests.memory` | Memory request per compiler pod. Heavier policy sets may need more; see [Compiler Resource Sizing](#compiler-resource-sizing). | `1Gi` |
| `compiler.resources.requests.cpu` | CPU request per compiler pod (about one in-flight compile slot). Raise this if you raise `compiler.maxConcurrent`; see [Compiler Resource Sizing](#compiler-resource-sizing). | `1000m` |
| `compiler.resources.limits.memory` | Memory limit per compiler pod. Memory is incompressible, so a limit is protective. | `4Gi` |
| `compiler.resources.limits.cpu` | CPU limit. Unset by default: the compiler can burst above its request while compiling, and a CPU limit throttles that work. `compiler.maxConcurrent` is the intended admission control. See [Compiler Resource Sizing](#compiler-resource-sizing). | _(unset)_ |
| `compiler.securityContext` | Container security context | See values.yaml |
| **SeaweedFS Operator** | | |
| `seaweedfsOperatorConfig.enabled` | Enable SeaweedFS Operator deployment | `true` |
| `seaweedfsOperatorConfig.seaweedfs.image.repository` | SeaweedFS image repository | `private-registry.nginx.com/nap/waf-seaweedfs` |
| `seaweedfsOperatorConfig.seaweedfs.image.tag` | SeaweedFS image tag | `5.16.1` |
| `seaweedfsOperatorConfig.seaweedfs.volumeServerDiskCount` | Number of disks per volume server | `1` |
| `seaweedfsOperatorConfig.seaweedfs.master.replicas` | Master node replicas | `1` |
| `seaweedfsOperatorConfig.seaweedfs.master.volumeSizeLimitMB` | Volume size limit in MB | `1024` |
| `seaweedfsOperatorConfig.seaweedfs.volume.replicas` | Volume server replicas | `3` |
| `seaweedfsOperatorConfig.seaweedfs.volume.requests.storage` | Storage size per volume | `2Gi` |
| `seaweedfsOperatorConfig.seaweedfs.volume.topology.rack` | Rack topology label | `rack1` |
| `seaweedfsOperatorConfig.seaweedfs.volume.topology.dataCenter` | Data center topology label | `dc1` |
| `seaweedfsOperatorConfig.seaweedfs.loggingLevel` | SeaweedFS logging level (0-5) | `1` |
| `seaweedfsOperatorConfig.seaweedfs.filer.replicas` | Filer replicas | `1` |
| `seaweedfsOperatorConfig.seaweedfs.filer.s3Identities` | Additional S3 identities (empty by default); each identity is converted to JSON and inserted into config.json identities array. Required fields per identity: name (string), actions (list), credentials (list of {accessKey, secretKey}) | `[]` |
| `seaweedfsOperatorConfig.seaweedfs.filer.filerHttpPort` | HTTP port for filer API | `8888` |
| `seaweedfsOperatorConfig.seaweedfs.filer.filerS3Port` | S3 API port for filer | `8333` |
| `seaweedfsOperatorConfig.seaweedfs.filer.filerS3HttpsPort` | HTTPS port for S3 API. **Requires `seaweedfsOperatorConfig.seaweedfs.certificates.enabled=true`** — setting this port without certificates enabled will cause the operator to reject the configuration and halt reconciliation. | `9333` |
| **SeaweedFS Filer Persistence** | | |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.enabled` | Enable persistent storage for filer metadata and data | `true` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.existingClaim` | Use an existing PVC instead of creating a new one (leave empty to auto-create) | `""` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.mountPath` | Mount path for the persistent volume inside the container | `/data` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.subPath` | Sub-path within the volume to mount | `""` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.accessModes` | Access modes for the PVC | `["ReadWriteOnce"]` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.selector` | Label selector for binding to specific PVs | `{}` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.resources.requests.storage` | Storage size for filer PVC | `4Gi` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.volumeName` | Specific PersistentVolume name to bind to (optional) | `""` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.storageClassName` | Storage class name (uses cluster default if empty) | `""` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.volumeMode` | Volume mode (Filesystem or Block) | `Filesystem` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.dataSource` | Data source for cloning from snapshots or templates | `{}` |
| **SeaweedFS Certificates** | | |
| `seaweedfsOperatorConfig.seaweedfs.certificates.enabled` | Enable TLS certificates for SeaweedFS components | `false` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.filerHttpsMtls` | Enable filer HTTPS mTLS mode by adding `[https.filer]` in `security.toml`; when true, filer liveness/readiness probes use HTTPS (requires `certificates.enabled=true`) | `false` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.caSecretName` | Secret name containing CA certificate | `<namespace>-seaweedfs-ca-cert` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.masterSecretName` | Secret name containing master node certificate | `<namespace>-seaweedfs-master-cert` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.volumeSecretName` | Secret name containing volume server certificate | `<namespace>-seaweedfs-volume-cert` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.filerSecretName` | Secret name containing filer certificate | `<namespace>-seaweedfs-filer-cert` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.clientSecretName` | Secret name containing client certificate | `<namespace>-seaweedfs-client-cert` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.securityConfigMapName` | ConfigMap name containing security.toml, if not set, a default ConfigMap will be used | `""` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.warnBefore` | Period before certificate expiration to warn (Go duration format) | `360h` |
| **SeaweedFS Operator Subchart** | | |
| `seaweedfs-operator.webhook.enabled` | Enable SeaweedFS operator webhook | `false` |
| `seaweedfs-operator.grafanaDashboard.enabled` | Enable Grafana dashboard for SeaweedFS | `false` |
| **Security Updates Repository Certificates** | | |
| `securityUpdatesRepo.cert` | Base64-encoded TLS certificate for security updates repository (optional) | `""` |
| `securityUpdatesRepo.key` | Base64-encoded TLS key for security updates repository (optional) | `""` |

## Compilation Capacity Sizing

The controller dispatch limit should stay at or below the available compiler capacity:

```text
controllerDispatch <= compiler.maxConcurrent * compiler.replicas
```

With [Compiler CPU HPA](#compiler-cpu-hpa) enabled, substitute `compiler.autoscaling.maxReplicas` for `compiler.replicas` when planning maximum dispatch; the template guard validates that maximum.

The shipped defaults are tuned for the dominant APPolicy-only steady state:

- `policyController.maxConcurrentCompilations: 4`
- `compiler.maxConcurrent: 4`
- `compiler.replicas: 1`

That gives matched capacity for APPolicy dispatch. The controller currently allocates one compilation pool per reconciler kind (`APPolicy` and `APLogConf`), so the theoretical worst case is `2 * policyController.maxConcurrentCompilations = 8` in-flight compile RPCs. This mismatch is accepted for now because APLogConf compilations are low-volume and compiler `ResourceExhausted` responses are retried as controller backpressure instead of being treated as permanent failures.

If you scale compiler replicas, raise the dispatch limit with it:

- `compiler.replicas: 2` -> `policyController.maxConcurrentCompilations: 8`
- `compiler.replicas: 3` -> `policyController.maxConcurrentCompilations: 12`

Do not over-dispatch above real compiler capacity; sustained over-dispatch reduces throughput and increases retry churn.

Example:

```bash
helm upgrade --install policy-controller charts/waf-policy-controller \
  --namespace policy-ns \
  --set policyController.maxConcurrentCompilations=8 \
  --set compiler.replicas=2 \
  --set compiler.maxConcurrent=4
```

## Compiler CPU HPA

Compiler CPU HPA is opt-in through `compiler.autoscaling.enabled`; it requires `metrics-server` to be installed in the cluster. The chart parses that setting strictly: case-insensitive `true` enables HPA, while case-insensitive `false`, including `--set-string compiler.autoscaling.enabled=false`, retains fixed-replica behavior. Other values fail rendering. While HPA is enabled, the compiler Deployment intentionally omits `spec.replicas` so Helm does not compete with the HPA during upgrades.

Enabling `compiler.autoscaling.enabled=true` is the only chart-side step. The
chart renders the HPA as part of the same release; customers do not install a
separate HPA manifest or extra RBAC for it.

`compiler.replicas` applies only in fixed-replica mode and does not constrain the HPA. For example, changing from `compiler.replicas: 5` to HPA with `minReplicas: 1` permits the HPA to scale down to one compiler pod. This is intentional; set `minReplicas` to the minimum operating capacity you require before enabling HPA.

Disabling autoscaling later by setting `compiler.autoscaling.enabled=false` deletes the chart-owned HPA on the next Helm upgrade and returns replica ownership to the Deployment's `spec.replicas`, sourced from `compiler.replicas`. Set `compiler.replicas` to the fixed capacity you actually want before disabling HPA, otherwise the Deployment falls back to that fixed-replica value even if the HPA had been running higher. If `policyController.maxConcurrentCompilations` was previously sized against `compiler.autoscaling.maxReplicas`, the chart may then fail rendering the [Compilation Capacity Sizing](#compilation-capacity-sizing) guard until you lower dispatch or raise the fixed replica count; that failure is expected and prevents an under-provisioned fixed-replica rollout.

The CPU target is measured relative to `compiler.resources.requests.cpu`. A positive CPU request is required when HPA is enabled; chart rendering fails if this value is null, empty, zero, or uses finer-than-`1m` CPU precision rather than creating an HPA without a utilization baseline. The helper accepts the common CPU forms used by this chart, such as `1000m`, `0.5`, and `1e-3`. The target must also be set to at least `1`. This HPA deliberately uses CPU only and does not scale directly from memory pressure.

Chart rendering also rejects a missing HPA minimum or maximum, an HPA minimum below `1`, a maximum below its minimum, or a missing or non-positive CPU target before Kubernetes returns an API validation error. These checks run through shared chart helpers, so invalid autoscaling settings fail consistently regardless of which template Helm evaluates first.

The shipped `70` percent target deliberately leaves CPU headroom before a compiler pod reaches its `1000m` request. Sizing measurements record a single-compile CPU peak near `972m`; HPA acts on sampled average utilization, but sustained work near that level can request another pod. That early scale-out trades additional pods for lower compiler backpressure and remains bounded by `maxReplicas`. Tune the target in environment-specific values when a different cost and latency balance is required.

The HPA intentionally uses a short 15-second scale-up stabilization window to respond promptly to sustained compilation demand and a 300-second scale-down window to avoid replica churn after bursts. These windows are fixed chart behavior so the scaling response remains consistent across installations.

When raising `compiler.autoscaling.maxReplicas`, size `policyController.maxConcurrentCompilations` proportionally so `controllerDispatch <= compiler.maxConcurrent * maxReplicas`. See [Compilation Capacity Sizing](#compilation-capacity-sizing) for the dispatch rule and fixed-replica guidance.

During scale-up, transient compiler backpressure and retries can occur until new compiler pods become Ready and the controller discovers them. Discovery is controlled by `policyController.compilerDNSRefreshInterval`; keep it enabled so the controller refreshes the headless compiler Service endpoints.

The chart does not currently add a compiler `preStop` hook or override `terminationGracePeriodSeconds`. If Kubernetes terminates a compiler pod with work in flight, the observed behavior depends on the compiler image's SIGTERM handling. On the controller side, interrupted RPCs follow the normal transport-failure or invalid-state retry paths; this chart does not yet claim image-level graceful drain semantics.

### Example: Enable Compiler CPU HPA

This example enables compiler autoscaling and keeps controller dispatch at the
default planned maximum capacity of `4 * 3 = 12`.

```bash
helm upgrade --install <release-name> . \
  --namespace <namespace> --create-namespace \
  --set compiler.autoscaling.enabled=true \
  --set compiler.autoscaling.minReplicas=1 \
  --set compiler.autoscaling.maxReplicas=3 \
  --set compiler.autoscaling.targetCPUUtilizationPercentage=70 \
  --set policyController.maxConcurrentCompilations=12 \
  --set compiler.maxConcurrent=4
```

After install or upgrade, verify that the HPA exists and the metrics pipeline
is serving pod metrics:

```bash
kubectl get hpa -n <namespace> <release-name>-f5-waf-compiler-service
kubectl top pods -n <namespace>
```

Expected result:

- The HPA exists as `<release-name>-f5-waf-compiler-service`.
- `kubectl top pods` returns CPU and memory values for pods in the namespace.
- If the HPA `TARGETS` column stays `<unknown>`, the HPA was rendered but the
  resource metrics API is still unavailable or not ready yet.

## Compiler Resource Sizing

The compiler's steady-state concurrency is bounded by its own admission control,
`compiler.maxConcurrent`, not by controller dispatch. If the controller
over-dispatches above real compiler capacity, the extra requests are rejected
with gRPC `ResourceExhausted` and retried as backpressure. This complements the
[Compilation Capacity Sizing](#compilation-capacity-sizing) rule.

The shipped defaults are:

- `compiler.resources.requests.cpu: 1000m`
- `compiler.resources.requests.memory: 1Gi`
- `compiler.resources.limits.memory: 4Gi`
- `compiler.resources.limits.cpu`: intentionally unset

Why the chart leaves CPU unlimited by default:

- A CPU limit throttles compile work.
- The compiler already has application-level admission control via
  `compiler.maxConcurrent`, which is the intended safety mechanism.
- If you raise `compiler.maxConcurrent`, also make sure the node has enough CPU
  headroom for the added concurrency.

Why the chart does set a memory limit:

- Memory is incompressible, so unlike CPU a limit is protective rather than
  throughput-harming.
- The shipped request and limit are conservative defaults intended to leave room
  for policy-mix variation while still capping a runaway.
- If your policies are materially heavier, re-check memory usage before
  tightening the limit.

Why the chart keeps the compiler Deployment on a zero-surge rollout strategy:

- The compiler Deployment ships `maxSurge: 0` and `maxUnavailable: 1`.
- With the shipped `compiler.resources.requests.cpu: 1000m`, the default
  Kubernetes surge behavior would briefly need `2 x requests.cpu` during a
  single-replica rollout.
- On a node sized for one compiler replica, that can deadlock
  `helm upgrade --wait` when a compiler pod-spec change forces a rollout.
- If you raise `requests.cpu` further, keep the zero-surge rollout strategy in
  place.

Overrides for constrained dev or CI clusters:

- You may add a `compiler.resources.limits.cpu` in an environment-specific
  override, but treat that as an explicit trade-off.
- A CPU quota throttles compile work and can reduce throughput.

These values are per compiler pod and scale linearly with `compiler.replicas`.
If you need to remove the default memory limit in an override, set
`compiler.resources.limits=null` rather than using `--set` on an individual
key.

## Resource Profiles

The values table above shows the shipped defaults. Production: use them as-is.
Override only when your cluster policy or measurements force it.

Development / CI: trade throughput for easier scheduling by lowering admitted
compiler concurrency and controller dispatch. With `compiler.maxConcurrent: 2`,
plan for about 2 vCPU of compiler headroom per pod instead of the shipped 4.

```yaml
compiler:
  maxConcurrent: 2
  resources:
    requests:
      cpu: 1000m
      memory: 1Gi
    limits:
      memory: 2Gi

policyController:
  maxConcurrentCompilations: 2   # must be <= compiler.maxConcurrent * compiler.replicas
  resources:
    requests:
      cpu: 100m
      memory: 128Mi
```

Clusters that mandate explicit CPU limits:

```yaml
compiler:
  resources:
    requests:
      cpu: 1000m
      memory: 1Gi
    limits:
      cpu: 6000m   # compiler.maxConcurrent * requests.cpu * 1.5
      memory: 4Gi

policyController:
  resources:
    requests:
      cpu: 250m
      memory: 128Mi
    limits:
      cpu: 2000m
      memory: 512Mi
```

Re-check both profiles when `compiler.maxConcurrent`, policy complexity, or
cluster density changes materially.

### LimitRange And ResourceQuota Compatibility

A namespace `LimitRange` can inject a `limits.cpu` the chart deliberately leaves
unset, and a `ResourceQuota` can reject those pods outright. Either way the
running pod differs from `helm template` output, so check before installing:

```bash
kubectl describe limitrange,resourcequota -n <namespace>
```

If your platform enforces CPU limits, set them explicitly with the profile above
rather than inheriting an injected default. To drop a limit, set the whole
`limits` block to `null` in a values file; `--set` cannot remove a single key.

### Guaranteed QoS

Every container, including init containers, needs matching CPU and memory
requests and limits. The compiler cannot reach Guaranteed: its
`init-app-protect` init container exposes no resource settings.

The policy-controller can, when the dependency-wait init container is not
rendered (`dependencyWait.enabled=false` or `seaweedfsOperatorConfig.enabled=false`),
`policyController.initContainers` is empty, and requests match limits:

```yaml
dependencyWait:
  enabled: false

policyController:
  resources:
    requests:
      cpu: 500m
      memory: 256Mi
    limits:
      cpu: 500m
      memory: 256Mi
```

Any custom init container added through `policyController.initContainers` must
also set matching CPU and memory requests and limits or the pod falls back to a
non-Guaranteed QoS class.

This removes burst headroom, so it raises throttling risk during reconcile
spikes. Verify rather than assume:

```bash
kubectl get pod -n <namespace> -l app.kubernetes.io/name=f5-waf-policy-controller \
  -o jsonpath='{.items[*].status.qosClass}{"\n"}'
```
