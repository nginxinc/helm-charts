# WAF Policy Lifecycle Manager Helm Chart

This Helm chart deploys the WAF Policy Lifecycle Manager components for managing security policies through Kubernetes custom resources.

## Overview

The chart provides:
- **Policy Controller**: Kubernetes operator that watches and manages AppProtect custom resources
- **Compiler**: Compiles security policies and bundles
- **Redis**: Message queue for policy compilation jobs
- **SeaweedFS**: S3-compatible storage for compiled policy bundles

## Prerequisites

- Kubernetes Cluster
- Helm 3.0+

## Custom Resource Definitions (CRDs)

This chart includes and automatically installs the following CRDs during initial installation:

- `appolicies.appprotect.f5.com`
- `aplogconfs.appprotect.f5.com`
- `apusersigs.appprotect.f5.com`
- `apsignatures.appprotect.f5.com`

**Important**: CRDs are only installed during `helm install`. They are **not** upgraded during `helm upgrade`. If you need to upgrade CRDs, you must apply them manually:

```bash
kubectl apply -f crds/
```


## Pull the Chart
1. Login to the registry
    ```
    helm registry login private-registry.nginx.com
    ```

1. Pull the chart
    ```
    helm pull oci://private-registry.nginx.com/nap/waf-policy-lifecycle-managment --version <release-version> --untar
    ```

1. Change your working directory to waf-policy-lifecycle-managment
    ```
    cd waf-policy-lifecycle-managment
    ```

### Basic Installation

```bash
helm install <release-name> .
```
Replace `<release-name>` with your desired release name.

### With Custom Values

```bash
helm install <release-name> . \
  --values custom-values.yaml
```


## Upgrade the Chart

### Upgrading CRDs

Helm does not upgrade CRDs during `helm upgrade`. If the chart version includes updated CRDs, you must manually apply them before upgrading:

```bash
kubectl apply -f crds/
```

Then proceed with the Helm upgrade:

```bash
helm upgrade <release-name> . --values custom-values.yaml
```

## Uninstall the Chart

```bash
helm uninstall <release-name>
```

**Note**: This will not delete:
- CRDs
- Persistent volumes (if using persistent storage)
- AppProtect custom resources

## Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| **Global Settings** | | |
| `namespace` | Target namespace | `""` (uses release namespace) |
| `imagePullSecrets` | List of image pull secret names to use for pulling container images | `[]` |
| `dockerConfigJson` | Docker config JSON for creating image pull secret | `""` |
| `dependencyWait.enabled` | When enabled (and seaweedfsOperatorConfig.enabled=true), add initContainers that wait for SeaweedFS S3 and Redis to be reachable before starting policy-controller/compiler | `true` |
| `dependencyWait.image.repository` | Init container image | `busybox` |
| `dependencyWait.image.tag` | Init container image tag | `1.36.1` |
| `dependencyWait.image.pullPolicy` | Init container image pull policy | `IfNotPresent` |
| `dependencyWait.timeoutSeconds` | Dependency wait timeout | `300` |
| **Policy Controller** | | |
| `policyController.replicas` | Number of controller replicas | `1` |
| `policyController.image.repository` | Controller image repository | `private-registry.nginx.com/nap/waf-policy-controller` |
| `policyController.image.tag` | Controller image tag | `5.13.0` |
| `policyController.image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `policyController.watchNamespace` | Namespaces to watch (comma-separated or empty for release namespace) | `""` |
| `policyController.s3.s3Endpoint` | Override S3 endpoint (auto-calculated if not set) | `""` |
| `policyController.s3.skipTlsVerify` | Skip TLS certificate verification (for testing with self-signed certificates) | `true` |
| `policyController.resources.requests.memory` | Memory request | `128Mi` |
| `policyController.resources.requests.cpu` | CPU request | `100m` |
| `policyController.securityContext` | Container security context | See values.yaml |
| `policyController.env` | Additional environment variables | `[]` |
| `policyController.initContainers` | Additional init containers | `[]` |
| `policyController.apsignatures.latestAll` | Signature updates behavior: on initial create, the chart defaults to an empty `apsignatures` spec; set to `true` to create it with `latest` for all signature revisions. Existing `apsignatures` settings are always preserved. | `false` |
| **Compiler** | | |
| `compiler.replicas` | Number of compiler replicas | `1` |
| `compiler.image.repository` | Compiler image repository | `private-registry.nginx.com/nap/waf-compiler` |
| `compiler.image.tag` | Compiler image tag | `5.13.0` |
| `compiler.image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `compiler.resources.requests.memory` | Memory request | `256Mi` |
| `compiler.resources.requests.cpu` | CPU request | `100m` |
| `compiler.securityContext` | Container security context | See values.yaml |
| **Redis** | | |
| `redis.replicas` | Number of Redis replicas | `1` |
| `redis.password` | Redis password (auto-generated if empty) | `""` |
| `redis.image.repository` | Redis image repository | `private-registry.nginx.com/nap/waf-redis` |
| `redis.image.tag` | Redis image tag | `5.13.0` |
| `redis.image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `redis.resources.requests.memory` | Memory request | `64Mi` |
| `redis.resources.requests.cpu` | CPU request | `50m` |
| `redis.securityContext` | Container security context | See values.yaml |
| **SeaweedFS Operator** | | |
| `seaweedfsOperatorConfig.enabled` | Enable SeaweedFS Operator deployment | `true` |
| `seaweedfsOperatorConfig.seaweedfs.image.repository` | SeaweedFS image repository | `private-registry.nginx.com/nap/waf-seaweedfs` |
| `seaweedfsOperatorConfig.seaweedfs.image.tag` | SeaweedFS image tag | `5.13.0` |
| `seaweedfsOperatorConfig.seaweedfs.volumeServerDiskCount` | Number of disks per volume server | `1` |
| `seaweedfsOperatorConfig.seaweedfs.master.replicas` | Master node replicas | `1` |
| `seaweedfsOperatorConfig.seaweedfs.master.volumeSizeLimitMB` | Volume size limit in MB | `1024` |
| `seaweedfsOperatorConfig.seaweedfs.volume.replicas` | Volume server replicas | `3` |
| `seaweedfsOperatorConfig.seaweedfs.volume.requests.storage` | Storage size per volume | `2Gi` |
| `seaweedfsOperatorConfig.seaweedfs.volume.topology.rack` | Rack topology label | `rack1` |
| `seaweedfsOperatorConfig.seaweedfs.volume.topology.dataCenter` | Data center topology label | `dc1` |
| `seaweedfsOperatorConfig.seaweedfs.loggingLevel` | SeaweedFS logging level (0-5) | `1` |
| `seaweedfsOperatorConfig.seaweedfs.filer.replicas` | Filer replicas | `1` |
| `seaweedfsOperatorConfig.seaweedfs.filer.filerHttpPort` | HTTP port for filer API | `8888` |
| `seaweedfsOperatorConfig.seaweedfs.filer.filerS3Port` | S3 API port for filer | `8333` |
| `seaweedfsOperatorConfig.seaweedfs.filer.filerS3HttpsPort` | HTTPS port for S3 API (requires certificates.enabled) | `9333` |
| **SeaweedFS Filer Persistence** | | |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.enabled` | Enable persistent storage for filer metadata and data | `true` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.existingClaim` | Use an existing PVC instead of creating a new one (leave empty to auto-create) | `""` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.mountPath` | Mount path for the persistent volume inside the container | `/data` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.subPath` | Sub-path within the volume to mount | `""` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.accessModes` | Access modes for the PVC | `["ReadWriteOnce"]` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.selector` | Label selector for binding to specific PVs | `{}` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.resources.requests.storage` | Storage size for filer PVC | `4Gi` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.volumeName` | Specific PersistentVolume name to bind to (optional) | `""` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.storageClassName` | Storage class name (uses cluster default if empty) | `""` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.volumeMode` | Volume mode (Filesystem or Block) | `Filesystem` |
| `seaweedfsOperatorConfig.seaweedfs.filer.persistence.dataSource` | Data source for cloning from snapshots or templates | `{}` |
| **SeaweedFS Certificates** | | |
| `seaweedfsOperatorConfig.seaweedfs.certificates.enabled` | Enable TLS certificates for SeaweedFS components | `false` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.caSecretName` | Secret name containing CA certificate | `<namespace>-seaweedfs-ca-cert` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.masterSecretName` | Secret name containing master node certificate | `<namespace>-seaweedfs-master-cert` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.volumeSecretName` | Secret name containing volume server certificate | `<namespace>-seaweedfs-volume-cert` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.filerSecretName` | Secret name containing filer certificate | `<namespace>-seaweedfs-filer-cert` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.clientSecretName` | Secret name containing client certificate | `<namespace>-seaweedfs-client-cert` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.securityConfigMapName` | ConfigMap name containing security.toml, if not set, a default ConfigMap will be used | `""` |
| `seaweedfsOperatorConfig.seaweedfs.certificates.warnBefore` | Period before certificate expiration to warn (Go duration format) | `360h` |
| **SeaweedFS Operator Subchart** | | |
| `seaweedfs-operator.webhook.enabled` | Enable SeaweedFS operator webhook | `false` |
| `seaweedfs-operator.grafanaDashboard.enabled` | Enable Grafana dashboard for SeaweedFS | `false` |
| **Security Updates Repository Certificates** | | |
| `securityUpdatesRepo.cert` | Base64-encoded TLS certificate for security updates repository (optional) | `""` |
| `securityUpdatesRepo.key` | Base64-encoded TLS key for security updates repository (optional) | `""` |
