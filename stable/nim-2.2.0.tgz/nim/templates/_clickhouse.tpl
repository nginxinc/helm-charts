{{/* ENV variables used by Clickhouse deployment */}}
{{- define "nms.clickhouse.env" }}
{{- if eq .Values.nmsClickhouse.mode "internal" }}
- name: CLICKHOUSE_ADDRESS
  value: {{ template "nms.clickhouse.service.tcp" . }}
- name: CLICKHOUSE_USER
  value: {{ .Values.nmsClickhouse.auth.username | quote }}
- name: CLICKHOUSE_PASSWORD
  {{ template "nms.clickhouse.admin-password" . }}
{{- else if eq .Values.nmsClickhouse.mode "external" }}
- name: CLICKHOUSE_ADDRESS
  value: {{ required "externalClickhouse.address is required when using external ClickHouse" .Values.externalClickhouse.address | quote }}
- name: CLICKHOUSE_USER
  value: {{ .Values.externalClickhouse.auth.username | default "" | quote }}
- name: CLICKHOUSE_PASSWORD
  {{ template "nms.externalClickhouse.admin-password" . }}
{{- else }}
# ClickHouse disabled
{{- end }}
{{- end }}

{*
   ------ NMS CLICKHOUSE ------
*}

{{/*
Return clickhouse fullname
*/}}
{{- define "nms.clickhouse.fullname" -}}
{{- if .Values.nmsClickhouse.fullnameOverride -}}
{{- .Values.nmsClickhouse.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" "clickhouse" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Common labels
*/}}

{{- define "nms.clickhouse.labels" -}}
helm.sh/chart: {{ include "nms.chart" . }}
{{ include "nms.clickhouse.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "nms.clickhouse.selectorLabels" -}}
app.kubernetes.io/name: {{ template "nms.clickhouse.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Pod labels
*/}}
{{- define "nms.clickhouse.podLabels" -}}
{{ include "nms.clickhouse.selectorLabels" . }}
{{- with .Values.podLabels }}
{{ toYaml . }}
{{- end }}
{{- with .Values.nmsClickhouse.pod.labels }}
{{ toYaml .  }}
{{- end }}
{{- end }}

{{/*
Return clickhouse address (k8s clickhouse service:port)
*/}}
{{- define "nms.clickhouse.service.tcp" -}}
tcp://{{ include "nms.clickhouse.fullname" . }}:{{ include "nms.clickhouse.containerPort.rpc" . }}
{{- end -}}

{{/*
Return clickhouse RPC port
*/}}
{{- define "nms.clickhouse.containerPort.rpc" -}}
{{ .Values.nmsClickhouse.service.rpcPort | default 9000 }}
{{- end -}}

{{/*
Return clickhouse http port
*/}}
{{- define "nms.clickhouse.containerPort.http" -}}
{{ .Values.nmsClickhouse.service.httpPort | default 8123 }}
{{- end -}}

{{/* Helper to get clickhouse storage class for storage provisioning */}}
{{- define "nms.clickhouse.storageClass" -}}
{{- if .Values.nmsClickhouse.persistence.storageClass }}
{{- if (eq "-" .Values.nmsClickhouse.persistence.storageClass) }}
storageClassName: ""
{{- else }}
storageClassName: "{{ .Values.nmsClickhouse.persistence.storageClass }}"
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "nms.clickhouse.userVolumes" -}}
- name: nms-clickhouse-volume
{{- if .Values.nmsClickhouse.persistence.enabled }}
  persistentVolumeClaim:
    claimName: {{ .existingClaim | default (include "nms.clickhouse.fullname" . ) }}
{{- else }}
  emptyDir: {}
{{- end -}}
{{- end -}}

{{- define "nms.clickhouse.userVolumeMounts" -}}
{{- if .Values.nmsClickhouse.persistence.enabled }}
- name: nms-clickhouse-volume
  mountPath: /var/lib/clickhouse
{{- end -}}
{{- end -}}

{{- define "nms.clickhouse.admin-password" -}}
{{- if .Values.nmsClickhouse.auth.existingSecret }}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.nmsClickhouse.auth.existingSecret }}
      key: {{ .Values.nmsClickhouse.auth.existingSecretKey }}
{{- else }}
  value: {{ .Values.nmsClickhouse.auth.password | quote }}
{{- end -}}
{{- end -}}

{{- define "nms.externalClickhouse.admin-password" -}}
{{- if .Values.externalClickhouse.auth.existingSecret -}}
  valueFrom:
    secretKeyRef:
      name: {{ .Values.externalClickhouse.auth.existingSecret }}
      key: {{ .Values.externalClickhouse.auth.existingSecretKey }}
{{- else }}
  value: {{ .Values.externalClickhouse.auth.password | quote }}
{{- end -}}
{{- end -}}

{{/* Helper to get clickhouse external ip from external address */}}
{{- define "nms.clickhouse.externalIP" -}}
{{- if .Values.externalClickhouse.address -}}
{{- $parts := (splitList ":" .Values.externalClickhouse.address) }}
{{- index $parts 0 }}
{{- end -}}
{{- end -}}



{{/* Helper to get clickhouse external port */}}
{{- define "nms.clickhouse.externalPort" -}}
{{- if .Values.externalClickhouse.address -}}
{{ $parts := (splitList ":" .Values.externalClickhouse.address) }}
{{- index $parts 1 }}
{{- end -}}
{{- end -}}

{{/* Helper to get clickhouse external port */}}
{{- define "nms.clickhouse.enableClickHouse" -}}
{{- if eq .Values.nmsClickhouse.mode "disabled" -}}
false
{{- else -}}
true
{{- end -}}
{{- end }}
