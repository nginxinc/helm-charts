{{/*
Expand the name of the chart.
*/}}
{{- define "nms.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "nms.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "nms.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}

{{- define "nms.labels" -}}
helm.sh/chart: {{ include "nms.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "nms.serviceAccountName" -}}
{{ .Values.serviceAccount.name | default "nms"}}
{{- end }}

{*
   ------ NMS configs and secrets ------
*}

{{/* Helper to return nms auth secret name */}}
{{- define "nms.secret.auth.name" -}}
{{ template "nms.fullname" . }}-auth
{{- end -}}

{{/* Helper to return the single monolithic internal certs secret name (legacy / default flow) */}}
{{- define "nms.secret.internal-certs.name" -}}
{{ template "nms.fullname" . }}-internal-certs
{{- end -}}

{{/* ---- Per-service internal certificate Secret name helpers (externalCerts flow only) ---- */}}

{{- define "nms.secret.ca.name" -}}
{{- if .Values.externalCerts.ca.secretName }}
{{- .Values.externalCerts.ca.secretName -}}
{{- else -}}
{{ template "nms.fullname" . }}-ca
{{- end }}
{{- end -}}

{{- define "nms.secret.core-certs.name" -}}
{{- if .Values.externalCerts.core.secretName }}
{{- .Values.externalCerts.core.secretName -}}
{{- else -}}
{{ template "nms.fullname" . }}-core-certs
{{- end }}
{{- end -}}

{{- define "nms.secret.dpm-certs.name" -}}
{{- if .Values.externalCerts.dpm.secretName }}
{{- .Values.externalCerts.dpm.secretName -}}
{{- else -}}
{{ template "nms.fullname" . }}-dpm-certs
{{- end }}
{{- end -}}

{{- define "nms.secret.ingestion-certs.name" -}}
{{- if .Values.externalCerts.ingestion.secretName }}
{{- .Values.externalCerts.ingestion.secretName -}}
{{- else -}}
{{ template "nms.fullname" . }}-ingestion-certs
{{- end }}
{{- end -}}

{{- define "nms.secret.integrations-certs.name" -}}
{{- if .Values.externalCerts.integrations.secretName }}
{{- .Values.externalCerts.integrations.secretName -}}
{{- else -}}
{{ template "nms.fullname" . }}-integrations-certs
{{- end }}
{{- end -}}

{{- define "nms.secret.secmon-certs.name" -}}
{{- if .Values.externalCerts.secmon.secretName }}
{{- .Values.externalCerts.secmon.secretName -}}
{{- else -}}
{{ template "nms.fullname" . }}-secmon-certs
{{- end }}
{{- end -}}

{{- define "nms.secret.apigw-client-certs.name" -}}
{{- if .Values.externalCerts.apigw.secretName }}
{{- .Values.externalCerts.apigw.secretName -}}
{{- else -}}
{{ template "nms.fullname" . }}-apigw-client-certs
{{- end }}
{{- end -}}

{{/* Helper to return nms gen certs secret name */}}
{{- define "nms.secret.apigw-certs.name" -}}
{{ template "nms.fullname" . }}-apigw-certs
{{- end -}}

{{/*
Returns "true" when at least one externalCerts entry is enabled.
Used by both the secrets template (to decide what to generate) and by
every workload template (to decide what to mount) so the two sides always
agree on which Secrets exist.
*/}}
{{- define "nms.externalCerts.anyEnabled" -}}
{{- if or .Values.externalCerts.ca.enabled
          .Values.externalCerts.core.enabled
          .Values.externalCerts.dpm.enabled
          .Values.externalCerts.ingestion.enabled
          .Values.externalCerts.integrations.enabled
          .Values.externalCerts.secmon.enabled
          .Values.externalCerts.apigw.enabled -}}
true
{{- end -}}
{{- end -}}

{{/*
Validates that the CA Secret contains ca.key when externalCerts.ca.enabled is true
and at least one other service cert is still being Helm-generated (i.e. any
externalCerts.<service>.enabled is false).

Background: the per-service cert-data templates sign new certs by looking up ca.key
from the CA Secret. If ca.key is absent, they silently fall back to a randomly
generated ephemeral CA — meaning every `helm upgrade` issues service certs from a
different CA root, breaking mTLS on rolling upgrades.

Call this once from nms-secrets.yaml at the start of the externalCerts block.
*/}}
{{- define "nms.validate.externalCerts.ca" -}}
{{- if .Values.externalCerts.ca.enabled }}
  {{- $anyServiceGenerated := or
      (not .Values.externalCerts.core.enabled)
      (not .Values.externalCerts.dpm.enabled)
      (not .Values.externalCerts.ingestion.enabled)
      (not .Values.externalCerts.integrations.enabled)
      (not .Values.externalCerts.secmon.enabled)
      (not .Values.externalCerts.apigw.enabled) -}}
  {{- if $anyServiceGenerated }}
    {{- /*
    NOTE: `lookup` always returns an empty dict during `helm template` (dry-run)
    and on the very first `helm install` before the Secret exists in the cluster.
    This guard therefore only fires on `helm upgrade` when the Secret is already
    present. For day-0 installs the user must ensure ca.key is included in the
    Secret before running `helm install`; that requirement is documented in
    values.yaml under externalCerts.ca.
    */ -}}
    {{- $caSecretObj := (lookup "v1" "Secret" .Release.Namespace (include "nms.secret.ca.name" .)) | default dict }}
    {{- $caData := (get $caSecretObj "data") | default dict }}
    {{- $caKey  := (get $caData "ca.key") | default "" }}
    {{- if eq $caKey "" }}
      {{- fail (printf "externalCerts.ca.enabled is true but Secret '%s' does not contain 'ca.key'. NIM must sign per-service certificates using your CA private key. Either: (a) include ca.key in the Secret, or (b) set externalCerts.<service>.enabled=true for every service so no Helm-side cert generation is needed." (include "nms.secret.ca.name" .)) }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end -}}

{{/* Helper to return nms.conf name */}}
{{- define "nms.config.name" -}}
{{ template "nms.fullname" . }}-conf
{{- end -}}

{{/* Helper to return nms-sm.conf name */}}
{{- define "nms.sm.config.name" -}}
{{ template "nms.fullname" . }}-sm-conf
{{- end -}}


{{/* Helper to return nms-http.conf name */}}
{{- define "nms.nginx.http.config.name" -}}
{{ template "nms.fullname" . }}-http-conf
{{- end -}}

{{/* Helper to return Nginx API Gateway config name */}}
{{- define "nms.nginx.config.name" -}}
{{ template "nms.fullname" . }}-nginx-conf
{{- end -}}

{{/* Helper to return openid config name */}}
{{- define "nms.openid.config.name" -}}
{{ template "nms.fullname" . }}-openid-conf
{{- end -}}

{{/* Helper to return nms-sm-proxy-mapping  */}}
{{- define "nms.secmon.config.name" -}}
{{ template "nms.fullname" . }}-sm-proxy-mapping
{{- end -}}

{{/* Helper to validate nms admin password required value */}}
{{- define "nms.admin-pwd" -}}
{{ required "A valid .Values.adminPasswordHash entry required!" .Values.adminPasswordHash }}
{{- end -}}

{{/*
=============================================================================
DEFAULT (legacy) certificate generation — one monolithic Secret.
=============================================================================
Used when externalCerts is not configured (all enabled: false, which is the
default). Generates the CA and every service cert/key into a single Secret
named <release>-internal-certs, exactly as before this commit.
*/}}
{{- define "nms.gen-internal-certs" -}}
{{- $ca := . }}
{{- $secretObj := (lookup "v1" "Secret" .Release.Namespace (include "nms.secret.internal-certs.name" . )) | default dict }}
{{- $secretData := (get $secretObj "data") | default dict }}
{{- $caKey := (get $secretData "ca.key") | default "" }}
{{- $caCert := (get $secretData "ca.pem") | default "" }}
{{- if eq $caKey "" }}
{{- $ca = genCA (include "nms.fullname" .) 36600 -}}
{{- end }}
{{- if ne $caKey ""}}
{{- $ca = buildCustomCert $caCert $caKey -}}
{{- end }}
{{- $servers := (list "core" "dpm" "ingestion" "integrations" "secmon") }}
{{- $clients := (list (include "nms.apigw.name" .) "core" "dpm" "ingestion" "integrations" "secmon") }}
{{- range $k, $v := $.Values.global.nmsModules }}
{{- range $i, $s := $v.services }}
{{- $servers = append $servers $s }}
{{- $clients = append $clients $s }}
{{- end }}
{{- end }}
{{- template "gen-certs" ( list $ca $servers $clients $secretData $ ) -}}
{{- end -}}

{{- define "gen-certs" -}}
{{- $ca := index . 0 }}
{{- $services := index . 1 }}
{{- $clients := index . 2 }}
{{- $existingCerts := index . 3 }}
{{- $ := index . 4 }}
ca.pem: {{ $ca.Cert | b64enc }}
ca.key: {{ $ca.Key | b64enc }}
{{- range $index, $serviceName := $services }}
{{- printf "\n" -}}
{{- $serverCert := (get $existingCerts (printf "%s-server.pem" $serviceName )) | default "" }}
{{- $serverKey := (get $existingCerts (printf "%s-server.key" $serviceName )) | default "" }}
{{- if ne $serverCert ""}}
{{ printf "%s-server.pem" $serviceName }}: {{ $serverCert }}
{{ printf "%s-server.key" $serviceName }}: {{ $serverKey }}
{{- else }}
{{- template "gen-server-certs" (list $serviceName $ca $) -}}
{{- end }}
{{- end }}
{{- range $index, $clientName := $clients }}
{{- printf "\n" -}}
{{- $clientCert := (get $existingCerts (printf "%s-client.pem" $clientName )) | default "" }}
{{- $clientKey := (get $existingCerts (printf "%s-client.key" $clientName )) | default "" }}
{{- if ne $clientCert ""}}
{{ printf "%s-client.pem" $clientName }}: {{ $clientCert }}
{{ printf "%s-client.key" $clientName }}: {{ $clientKey }}
{{- else }}
{{- template "gen-client-certs" (list $clientName $ca) -}}
{{- end }}
{{- end }}
{{- end -}}

{{- define "gen-server-certs" -}}
{{- $serviceName := index . 0 }}
{{- $ca := index . 1 }}
{{- $ := index . 2 }}
{{- $altNames := (list $serviceName (printf "%s.%s.svc" $serviceName $.Release.Namespace ) (printf "%s.%s.svc.cluster.local" $serviceName $.Release.Namespace )) -}}
{{- $ips := (list "0.0.0.0" "127.0.0.1") -}}
{{- $cert := genSignedCert ( printf "%s.%s" $serviceName $.Release.Namespace ) $ips $altNames 36600 $ca -}}
{{ printf "%s-server.pem" $serviceName }}: {{ $cert.Cert | b64enc }}
{{ printf "%s-server.key" $serviceName }}: {{ $cert.Key | b64enc }}
{{- end -}}

{{- define "gen-client-certs" -}}
{{- $clientName := index . 0 }}
{{- $ca := index . 1 }}
{{- $altNames := (list (printf "%s-api-service" $clientName ) (printf "%s-grpc-service" $clientName )) -}}
{{- $cert := genSignedCert ( printf "%s-client" $clientName ) nil $altNames 36600 $ca -}}
{{ printf "%s-client.pem" $clientName }}: {{ $cert.Cert | b64enc }}
{{ printf "%s-client.key" $clientName }}: {{ $cert.Key | b64enc }}
{{- end -}}

{{/*
=============================================================================
EXTERNAL CERTS (new) — per-service Secret generation helpers.
=============================================================================
Only used when externalCerts.*.enabled is true for one or more services.
Each helper is self-contained: it looks up (or generates) the CA from the
CA Secret directly within its own template scope, so the sprig.certificate
type never crosses a template boundary (which would corrupt it via string
serialisation).
*/}}

{{/* CA Secret data — renders ca.pem and ca.key for the CA-only Secret */}}
{{- define "nms.gen-ca-secret-data" -}}
{{- $caSecretObj := (lookup "v1" "Secret" .Release.Namespace (include "nms.secret.ca.name" . )) | default dict }}
{{- $caData := (get $caSecretObj "data") | default dict }}
{{- $caKey  := (get $caData "ca.key") | default "" }}
{{- $caCert := (get $caData "ca.pem") | default "" }}
{{- if and (ne $caCert "") (eq $caKey "") }}
  {{- fail (printf "Secret '%s' contains 'ca.pem' but is missing 'ca.key'. Both must be provided together." (include "nms.secret.ca.name" .)) }}
{{- end }}
{{- $ca := genCA (include "nms.fullname" .) 36600 }}
{{- if and (ne $caKey "") (ne $caCert "") }}
{{- $ca = buildCustomCert $caCert $caKey }}
{{- end }}
ca.pem: {{ $ca.Cert | b64enc }}
ca.key: {{ $ca.Key | b64enc }}
{{- end -}}

{{/* core Secret data: server + client cert/key */}}
{{- define "nms.gen-core-cert-data" -}}
{{- $caSecretObj := (lookup "v1" "Secret" .Release.Namespace (include "nms.secret.ca.name" . )) | default dict }}
{{- $caData := (get $caSecretObj "data") | default dict }}
{{- $caKey  := (get $caData "ca.key") | default "" }}
{{- $caCert := (get $caData "ca.pem") | default "" }}
{{- if and (ne $caCert "") (eq $caKey "") }}
  {{- fail (printf "Secret '%s' contains 'ca.pem' but is missing 'ca.key'. Both must be provided together." (include "nms.secret.ca.name" .)) }}
{{- end }}
{{- $ca := genCA (include "nms.fullname" .) 36600 }}
{{- if and (ne $caKey "") (ne $caCert "") }}
{{- $ca = buildCustomCert $caCert $caKey }}
{{- end }}
{{- $altNames := list "core" (printf "core.%s.svc" .Release.Namespace) (printf "core.%s.svc.cluster.local" .Release.Namespace) }}
{{- $serverCert := genSignedCert (printf "core.%s" .Release.Namespace) (list "0.0.0.0" "127.0.0.1") $altNames 36600 $ca }}
{{- $clientCert := genSignedCert "core-client" nil (list "core-api-service" "core-grpc-service") 36600 $ca }}
core-server.pem: {{ $serverCert.Cert | b64enc }}
core-server.key: {{ $serverCert.Key | b64enc }}
core-client.pem: {{ $clientCert.Cert | b64enc }}
core-client.key: {{ $clientCert.Key | b64enc }}
{{- end -}}

{{/* dpm Secret data: server + client cert/key */}}
{{- define "nms.gen-dpm-cert-data" -}}
{{- $caSecretObj := (lookup "v1" "Secret" .Release.Namespace (include "nms.secret.ca.name" . )) | default dict }}
{{- $caData := (get $caSecretObj "data") | default dict }}
{{- $caKey  := (get $caData "ca.key") | default "" }}
{{- $caCert := (get $caData "ca.pem") | default "" }}
{{- if and (ne $caCert "") (eq $caKey "") }}
  {{- fail (printf "Secret '%s' contains 'ca.pem' but is missing 'ca.key'. Both must be provided together." (include "nms.secret.ca.name" .)) }}
{{- end }}
{{- $ca := genCA (include "nms.fullname" .) 36600 }}
{{- if and (ne $caKey "") (ne $caCert "") }}
{{- $ca = buildCustomCert $caCert $caKey }}
{{- end }}
{{- $altNames := list "dpm" (printf "dpm.%s.svc" .Release.Namespace) (printf "dpm.%s.svc.cluster.local" .Release.Namespace) }}
{{- $serverCert := genSignedCert (printf "dpm.%s" .Release.Namespace) (list "0.0.0.0" "127.0.0.1") $altNames 36600 $ca }}
{{- $clientCert := genSignedCert "dpm-client" nil (list "dpm-api-service" "dpm-grpc-service") 36600 $ca }}
dpm-server.pem: {{ $serverCert.Cert | b64enc }}
dpm-server.key: {{ $serverCert.Key | b64enc }}
dpm-client.pem: {{ $clientCert.Cert | b64enc }}
dpm-client.key: {{ $clientCert.Key | b64enc }}
{{- end -}}

{{/* ingestion Secret data: server + client cert/key */}}
{{- define "nms.gen-ingestion-cert-data" -}}
{{- $caSecretObj := (lookup "v1" "Secret" .Release.Namespace (include "nms.secret.ca.name" . )) | default dict }}
{{- $caData := (get $caSecretObj "data") | default dict }}
{{- $caKey  := (get $caData "ca.key") | default "" }}
{{- $caCert := (get $caData "ca.pem") | default "" }}
{{- if and (ne $caCert "") (eq $caKey "") }}
  {{- fail (printf "Secret '%s' contains 'ca.pem' but is missing 'ca.key'. Both must be provided together." (include "nms.secret.ca.name" .)) }}
{{- end }}
{{- $ca := genCA (include "nms.fullname" .) 36600 }}
{{- if and (ne $caKey "") (ne $caCert "") }}
{{- $ca = buildCustomCert $caCert $caKey }}
{{- end }}
{{- $altNames := list "ingestion" (printf "ingestion.%s.svc" .Release.Namespace) (printf "ingestion.%s.svc.cluster.local" .Release.Namespace) }}
{{- $serverCert := genSignedCert (printf "ingestion.%s" .Release.Namespace) (list "0.0.0.0" "127.0.0.1") $altNames 36600 $ca }}
{{- $clientCert := genSignedCert "ingestion-client" nil (list "ingestion-api-service" "ingestion-grpc-service") 36600 $ca }}
ingestion-server.pem: {{ $serverCert.Cert | b64enc }}
ingestion-server.key: {{ $serverCert.Key | b64enc }}
ingestion-client.pem: {{ $clientCert.Cert | b64enc }}
ingestion-client.key: {{ $clientCert.Key | b64enc }}
{{- end -}}

{{/* integrations Secret data: server + client cert/key */}}
{{- define "nms.gen-integrations-cert-data" -}}
{{- $caSecretObj := (lookup "v1" "Secret" .Release.Namespace (include "nms.secret.ca.name" . )) | default dict }}
{{- $caData := (get $caSecretObj "data") | default dict }}
{{- $caKey  := (get $caData "ca.key") | default "" }}
{{- $caCert := (get $caData "ca.pem") | default "" }}
{{- if and (ne $caCert "") (eq $caKey "") }}
  {{- fail (printf "Secret '%s' contains 'ca.pem' but is missing 'ca.key'. Both must be provided together." (include "nms.secret.ca.name" .)) }}
{{- end }}
{{- $ca := genCA (include "nms.fullname" .) 36600 }}
{{- if and (ne $caKey "") (ne $caCert "") }}
{{- $ca = buildCustomCert $caCert $caKey }}
{{- end }}
{{- $altNames := list "integrations" (printf "integrations.%s.svc" .Release.Namespace) (printf "integrations.%s.svc.cluster.local" .Release.Namespace) }}
{{- $serverCert := genSignedCert (printf "integrations.%s" .Release.Namespace) (list "0.0.0.0" "127.0.0.1") $altNames 36600 $ca }}
{{- $clientCert := genSignedCert "integrations-client" nil (list "integrations-api-service" "integrations-grpc-service") 36600 $ca }}
integrations-server.pem: {{ $serverCert.Cert | b64enc }}
integrations-server.key: {{ $serverCert.Key | b64enc }}
integrations-client.pem: {{ $clientCert.Cert | b64enc }}
integrations-client.key: {{ $clientCert.Key | b64enc }}
{{- end -}}

{{/* secmon Secret data: server + client cert/key */}}
{{- define "nms.gen-secmon-cert-data" -}}
{{- $caSecretObj := (lookup "v1" "Secret" .Release.Namespace (include "nms.secret.ca.name" . )) | default dict }}
{{- $caData := (get $caSecretObj "data") | default dict }}
{{- $caKey  := (get $caData "ca.key") | default "" }}
{{- $caCert := (get $caData "ca.pem") | default "" }}
{{- if and (ne $caCert "") (eq $caKey "") }}
  {{- fail (printf "Secret '%s' contains 'ca.pem' but is missing 'ca.key'. Both must be provided together." (include "nms.secret.ca.name" .)) }}
{{- end }}
{{- $ca := genCA (include "nms.fullname" .) 36600 }}
{{- if and (ne $caKey "") (ne $caCert "") }}
{{- $ca = buildCustomCert $caCert $caKey }}
{{- end }}
{{- $altNames := list "secmon" (printf "secmon.%s.svc" .Release.Namespace) (printf "secmon.%s.svc.cluster.local" .Release.Namespace) }}
{{- $serverCert := genSignedCert (printf "secmon.%s" .Release.Namespace) (list "0.0.0.0" "127.0.0.1") $altNames 36600 $ca }}
{{- $clientCert := genSignedCert "secmon-client" nil (list "secmon-api-service" "secmon-grpc-service") 36600 $ca }}
secmon-server.pem: {{ $serverCert.Cert | b64enc }}
secmon-server.key: {{ $serverCert.Key | b64enc }}
secmon-client.pem: {{ $clientCert.Cert | b64enc }}
secmon-client.key: {{ $clientCert.Key | b64enc }}
{{- end -}}

{{/* apigw-client Secret data: client cert/key only */}}
{{- define "nms.gen-apigw-client-cert-data" -}}
{{- $caSecretObj := (lookup "v1" "Secret" .Release.Namespace (include "nms.secret.ca.name" . )) | default dict }}
{{- $caData := (get $caSecretObj "data") | default dict }}
{{- $caKey  := (get $caData "ca.key") | default "" }}
{{- $caCert := (get $caData "ca.pem") | default "" }}
{{- if and (ne $caCert "") (eq $caKey "") }}
  {{- fail (printf "Secret '%s' contains 'ca.pem' but is missing 'ca.key'. Both must be provided together." (include "nms.secret.ca.name" .)) }}
{{- end }}
{{- $ca := genCA (include "nms.fullname" .) 36600 }}
{{- if and (ne $caKey "") (ne $caCert "") }}
{{- $ca = buildCustomCert $caCert $caKey }}
{{- end }}
{{- $apigwName := include "nms.apigw.name" . | trim }}
{{- $clientCert := genSignedCert (printf "%s-client" $apigwName) nil (list (printf "%s-api-service" $apigwName) (printf "%s-grpc-service" $apigwName)) 36600 $ca }}
{{ printf "%s-client.pem" $apigwName }}: {{ $clientCert.Cert | b64enc }}
{{ printf "%s-client.key" $apigwName }}: {{ $clientCert.Key | b64enc }}
{{- end -}}

{{/* Helper to return nms internal certs dir */}}
{{- define "nms.secret.internal-certs.dir" -}}
/etc/nms/certs/services
{{- end -}}

{{/*
Generates self-signed CA and server certificate for the apigw HTTPS endpoint.
Only used when apigw.tlsSecret is not set (auto-generated path).
*/}}
{{- define "nms.gen-apigw-certs" -}}
{{- $subjectName := include "nms.apigw.name" . }}
{{- $ca := genCA (include "nms.fullname" .) 36600 -}}
{{- $altNames := (list $subjectName (printf "%s.%s.svc" $subjectName .Release.Namespace) (printf "%s.%s.svc.cluster.local" $subjectName .Release.Namespace)) -}}
{{- $cert := genSignedCert (printf "%s.%s" $subjectName .Release.Namespace) (list "0.0.0.0" "127.0.0.1") $altNames 36600 $ca -}}
ca.pem: {{ $ca.Cert | b64enc }}
tls.crt: {{ $cert.Cert | b64enc }}
tls.key: {{ $cert.Key | b64enc }}
{{- end -}}

{*
   ------ Clickhouse ------
*}

{{/* ENV variables used by NMS process to talk to Clickhouse */}}
{{- define "nms.clickhouse.conf" }}
{{- if eq .Values.nmsClickhouse.mode "internal" }}
- name: NMS_CLICKHOUSE_ADDRESS
  value: {{ template "nms.clickhouse.service.tcp" . }}
- name: NMS_CLICKHOUSE_USERNAME
  value: {{ .Values.nmsClickhouse.auth.username | quote }}
- name: NMS_CLICKHOUSE_PASSWORD
  {{ template "nms.clickhouse.admin-password" . }}
{{- else if eq .Values.nmsClickhouse.mode "external" }}
- name: NMS_CLICKHOUSE_ADDRESS
  value: {{ required "externalClickhouse.address is required when using external ClickHouse" .Values.externalClickhouse.address | quote }}
- name: NMS_CLICKHOUSE_USERNAME
  value: {{ .Values.externalClickhouse.auth.username | default "" | quote }}
- name: NMS_CLICKHOUSE_PASSWORD
  {{ template "nms.externalClickhouse.admin-password" . }}
{{- else }}
# ClickHouse is disabled
{{- end }}
{{- end }}

{*
   ------ Nginx API-GW ------
*}

{{/* Helper to return nginx apigw name */}}
{{- define "nms.apigw.name" -}}
{{ .Values.apigw.name | default "apigw" }}
{{- end -}}

{{/* Helper to return nginx apigw service name */}}
{{- define "nms.apigw.service.name" -}}
{{ .Values.apigw.service.name | default "apigw" }}
{{- end -}}

{{- define "nms.apigw.selectorLabels" -}}
app.kubernetes.io/name: {{ template "nms.apigw.name" . }}
{{- end }}

{{- define "nms.apigw.podLabels" -}}
{{ include "nms.apigw.selectorLabels" . }}
{{- with .Values.podLabels }}
{{ toYaml . }}
{{- end }}
{{- with .Values.apigw.pod.labels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/* Helper function to determine which secret needs to be used for apigw */}}
{{- define "nms.apigw.secret-name" -}}
{{- if .Values.apigw.tlsSecret }}
{{- .Values.apigw.tlsSecret -}}
{{ else }}
{{- template "nms.secret.apigw-certs.name" . -}}
{{- end }}
{{- end -}}

{{/* Helper function to return api-gw secrets mount path */}}
{{- define "nms.apigw.secrets.mountPath" -}}
/etc/nms/certs/apigw
{{- end -}}

{{/* Helper function to return api-gw crt file name */}}
{{- define "nms.apigw.secrets.crt" -}}
{{- template "nms.apigw.secrets.mountPath" . -}}/tls.crt
{{- end -}}

{{/* Helper function to give generated api-gw tls key file name */}}
{{- define "nms.apigw.secrets.key" -}}
{{- template "nms.apigw.secrets.mountPath" . -}}/tls.key
{{- end -}}

{{/* Helper function to give generated api-gw ca file name */}}
{{- define "nms.apigw.secrets.ca" -}}
{{- template "nms.apigw.secrets.mountPath" . -}}/ca.pem
{{- end -}}

{{/* Helper functions for mounting module configuration */}}
{{- define "nms.apigw.moduleVolumeMounts" -}}
{{- range $k, $v := .Values.global.nmsModules }}
{{- if $v.enabled }}
{{- range $i, $config := $v.configs }}
{{- range $j, $key := $config.upstreams }}
- name: {{ $config.configmap }}
  mountPath: /etc/nms/nginx/upstreams/{{ $key }}
  subPath: {{ $key }}
  readOnly: true
{{- end }}
{{- range $j, $key := $config.mapped_apis }}
- name: {{ $config.configmap }}
  mountPath: /etc/nms/nginx/upstreams/mapped_apis/{{ $key }}
  subPath: {{ $key }}
  readOnly: true
{{- end }}
{{- range $j, $key := $config.locations }}
- name: {{ $config.configmap }}
  mountPath: /etc/nms/nginx/locations/{{ $key }}
  subPath: {{ $key }}
  readOnly: true
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "nms.apigw.moduleVolumes" -}}
{{- range $k, $v := .Values.global.nmsModules }}
{{- if $v.enabled }}
{{- range $i, $u := $v.configs }}
- name: {{ $u.configmap }}
  configMap:
    defaultMode: 0644
    name: {{ $u.configmap }}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "nms.apigw.nginxWorkerConnections" -}}
{{ .Values.apigw.nginxWorkerConnections | default 1024 }}
{{- end -}}

{{- define "nms.apigw.nginxWorkerRlimitNofile" -}}
{{ .Values.apigw.nginxWorkerRlimitNofile | default 4096 }}
{{- end -}}

{{/*
Helper to return the NGINX server_name value for the API gateway.
Defaults to "_" (catch-all) when apigw.serverName is not set.
Supports a single domain or a space-separated list of domains,
e.g. "nim.example.com nim-internal.example.com".
*/}}
{{- define "nms.apigw.serverName" -}}
{{- .Values.apigw.serverName | default "_" -}}
{{- end -}}

{*
   ------ Core ------
*}

{{/* ENV variables */}}
{{- define "nms.core.env" -}}
- name: NMS_DPM_NATS_ADDRESS
  value: {{ template "nms.dpm.service.natsStreaming" . }}
- name: NMS_INTEGRATIONS_ADDRESS
  value: {{ template "nms.integrations.service.http" . }}
{{- end }}

{{/* Helper to return core name */}}
{{- define "nms.core.name" -}}
{{ .Values.core.name | default "core" }}
{{- end -}}

{{/* Helper to return Core http container bind address */}}
{{- define "nms.core.httpAddress" -}}
0.0.0.0:{{ template "nms.core.httpPort" . }}
{{- end -}}

{{/* Helper to return core container http port */}}
{{- define "nms.core.httpPort" -}}
{{ .Values.core.container.port.http | default 8033 }}
{{- end -}}

{{/* Helper to return core service http port */}}
{{- define "nms.core.service.httpPort" -}}
{{ .Values.core.service.httpPort | default 8033 }}
{{- end -}}

{{/* Helper to return Core grpc container bind address */}}
{{- define "nms.core.grpcAddress" -}}
0.0.0.0:{{ template "nms.core.grpcPort" . }}
{{- end -}}

{{/* Helper to return core container grpc port */}}
{{- define "nms.core.grpcPort" -}}
{{ .Values.core.container.port.grpc | default 8038 }}
{{- end -}}

{{/* Helper to return core service grpc port */}}
{{- define "nms.core.service.grpcPort" -}}
{{ .Values.core.service.grpcPort | default 8038 }}
{{- end -}}

{{/* Helper to return core db port */}}
{{- define "nms.core.dbPort" -}}
{{ .Values.core.container.port.db | default 7891 }}
{{- end -}}

{{/* Helper to return secrets driver type */}}
{{- define "nms.secret.driverType" -}}
{{- if or .Values.nmsVault.enabled .Values.externalVault.address -}}
vault
{{- else -}}
local
{{- end }}
{{- end }}


{{/* Helper to return Core dqlite container bind address */}}
{{- define "nms.core.dqliteAddress" -}}
{{ "0.0.0.0" }}:{{ .Values.core.container.port.db | default 7891 }}
{{- end -}}

{{/* Helper to return core http endpoint */}}
{{- define "nms.core.service.http" -}}
{{ template "nms.core.name" . }}:{{ template "nms.core.service.httpPort" . }}
{{- end -}}

{{/* Helper to return core db endpoint */}}
{{- define "nms.core.dbPortTcp" -}}
{{ template "nms.core.name" . }}:{{ template "nms.core.dbPort" . }}
{{- end -}}

{{/* Helper to return core service dqlite endpoint */}}
{{- define "nms.core.service.dqlite" -}}
{{ template "nms.core.name" . }}:{{ template "nms.core.dbPort" . }}
{{- end -}}

{{/* Helper to return core grpc endpoint */}}
{{- define "nms.core.service.grpc" -}}
{{ template "nms.core.name" . }}:{{ template "nms.core.service.grpcPort" . }}
{{- end -}}

{{- define "nms.core.selectorLabels" -}}
app.kubernetes.io/name: {{ template "nms.core.name" . }}
{{- end }}

{{- define "nms.core.podLabels" -}}
{{ include "nms.core.selectorLabels" . }}
{{- with .Values.podLabels }}
{{ toYaml . }}
{{- end }}
{{- with .Values.core.pod.labels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/* Helper to get core storage class for storage provisioning */}}
{{- define "nms.core.storageClass" -}}
{{- if .Values.core.persistence.storageClass }}
{{- if (eq "-" .Values.core.persistence.storageClass) }}
storageClassName: ""
{{- else }}
storageClassName: "{{ .Values.core.persistence.storageClass }}"
{{- end }}
{{- end }}
{{- end }}

{{- define "nms.core.userVolumes" -}}
{{- if .Values.core.persistence.enabled }}
{{- range .Values.core.persistence.claims }}
{{- if eq "dqlite" .name }}
- name: dqlite-volume
  persistentVolumeClaim:
    claimName: {{ .existingClaim | default (printf "%s-%s" (include "nms.core.name" $ ) .name) }}
{{- else if eq "secrets" .name }}
- name: secrets-volume
  persistentVolumeClaim:
    claimName: {{ .existingClaim | default (printf "%s-%s" (include "nms.core.name" $ ) .name) }}
{{- end }}
{{- end }}
{{- else }}
- name: dqlite-volume
  emptyDir: {}
- name: secrets-volume
  emptyDir: {}
{{- end -}}
{{- end -}}

{{- define "nms.core.userVolumeMounts" -}}
- name: dqlite-volume
  mountPath: /var/lib/nms/dqlite
- name: secrets-volume
  mountPath: /var/lib/nms/secrets
{{- end -}}

{{- define "nms.core.moduleVolume" -}}
{{- $length := len .Values.global.nmsModules -}}
{{- if ne $length 0 -}}
- name: nms-modules-volume
  projected:
    sources:
    {{- range $k, $v := .Values.global.nmsModules }}
    {{- if $v.enabled }}
    {{- range $kc, $c := $v.configs }}
    {{- if gt (len $c.modules) 0 }}
    - configMap:
        name: {{ $c.configmap }}
        items:
        {{- range $i, $key := $c.modules }}
        - key: {{ $key }}
          path: {{ $key }}
        {{- end }}
    {{- end }}
    {{- end }}
    {{- end }}
    {{- end }}
{{- end -}}
{{- end -}}

{{- define "nms.core.moduleVolumeMounts" -}}
{{- $length := len .Values.global.nmsModules -}}
{{- if ne $length 0 -}}
- name: nms-modules-volume
  mountPath: /var/lib/nms/modules
{{- end -}}
{{- end -}}

{*
   ------ DPM ------
*}

{{/* ENV variables used by nms-dpm */}}
{{- define "nms.dpm.env" -}}
- name: NMS_INTEGRATIONS_ADDRESS
  value: {{ template "nms.integrations.service.http" . }}
- name: NMS_CORE_ADDRESS
  value: {{ template "nms.core.service.http" . }}
- name: NMS_CORE_DQLITE_ADDR
  value: {{ template "nms.core.dbPortTcp" . }}
{{- end }}

{{/* Helper to return DPM http container bind address */}}
{{- define "nms.dpm.httpAddress" -}}
0.0.0.0:{{ template "nms.dpm.httpPort" . }}
{{- end -}}

{{/* Helper to return DPM dqlite container bind address */}}
{{- define "nms.dpm.dqliteAddress" -}}
{{ "0.0.0.0" }}:{{ .Values.dpm.container.port.db | default 7890 }}
{{- end -}}

{{/* Helper to return DPM grpc container bind address */}}
{{- define "nms.dpm.grpcAddress" -}}
0.0.0.0:{{ template "nms.dpm.grpcPort" . }}
{{- end -}}

{{/* Helper to return dpm name */}}
{{- define "nms.dpm.name" -}}
{{ .Values.dpm.name | default "dpm" }}
{{- end -}}

{{/* Helper to return NATS streaming service */}}
{{- define "nms.dpm.service.natsStreaming" -}}
nats://{{ template "nms.dpm.name" . }}:{{ template "nms.dpm.service.natsStreamingPort" . }}
{{- end -}}

{{/* Helper to return NATS streaming service port */}}
{{- define "nms.dpm.service.natsStreamingPort" -}}
{{ .Values.dpm.service.natsPort | default 9100 }}
{{- end -}}

{{/* Helper to return NATS streaming container port */}}
{{- define "nms.dpm.natsStreamingPort" -}}
{{ .Values.dpm.container.port.nats | default 9100 }}
{{- end -}}

{{/* Helper to return dpm http service */}}
{{- define "nms.dpm.service.http" -}}
{{ template "nms.dpm.name" . }}:{{ template "nms.dpm.service.httpPort" . }}
{{- end -}}


{{/* Helper to return dpm container http port */}}
{{- define "nms.dpm.httpPort" -}}
{{ .Values.dpm.container.port.http | default 8034 }}
{{- end -}}

{{/* Helper to return dpm service http port */}}
{{- define "nms.dpm.service.httpPort" -}}
{{ .Values.dpm.service.httpPort | default 8034 }}
{{- end -}}

{{/* Helper to return dpm grpc service */}}
{{- define "nms.dpm.service.grpc" -}}
{{ template "nms.dpm.name" . }}:{{ template "nms.dpm.service.grpcPort" . }}
{{- end -}}

{{/* Helper to return dpm container grpc port */}}
{{- define "nms.dpm.grpcPort" -}}
{{ .Values.dpm.container.port.grpc | default 8036 }}
{{- end -}}

{{/* Helper to return dpm service grpc port */}}
{{- define "nms.dpm.service.grpcPort" -}}
{{ .Values.dpm.service.grpcPort | default 8036 }}
{{- end -}}

{{- define "nms.dpm.selectorLabels" -}}
app.kubernetes.io/name: {{ template "nms.dpm.name" . }}
{{- end }}

{{- define "nms.dpm.podLabels" -}}
{{ include "nms.dpm.selectorLabels" . }}
{{- with .Values.podLabels }}
{{ toYaml . }}
{{- end }}
{{- with .Values.dpm.pod.labels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/* Helper to get dpm storage class for storage provisioning */}}
{{- define "nms.dpm.storageClass" -}}
{{- if .Values.dpm.persistence.storageClass }}
{{- if (eq "-" .Values.dpm.persistence.storageClass) }}
storageClassName: ""
{{- else }}
storageClassName: "{{ .Values.dpm.persistence.storageClass }}"
{{- end }}
{{- end }}
{{- end }}

{{- define "nms.dpm.userVolumes" -}}
{{- if .Values.dpm.persistence.enabled }}
{{- range .Values.dpm.persistence.claims }}
{{- if eq "dqlite" .name }}
- name: dqlite-volume
  persistentVolumeClaim:
    claimName: {{ .existingClaim | default ( printf "%s-%s" (include "nms.dpm.name" $ ) .name ) }}
{{- else if eq "nats-streaming" .name }}
- name: nats-streaming-volume
  persistentVolumeClaim:
    claimName: {{ .existingClaim | default ( printf "%s-%s" (include "nms.dpm.name" $ ) .name ) }}
{{- end -}}
{{- end -}}
{{- else }}
- name: dqlite-volume
  emptyDir: {}
- name: nats-streaming-volume
  emptyDir: {}
{{- end -}}
{{- end -}}

{{- define "nms.dpm.userVolumeMounts" -}}
- name: dqlite-volume
  mountPath: /var/lib/nms/dqlite
- name: nats-streaming-volume
  mountPath: /var/lib/nms/streaming
{{- end -}}

{*
   ------ Ingestion ------
*}

{{/* ENV variables nms-ingestion */}}
{{- define "nms.ingestion.env" -}}
- name: NMS_DPM_NATS_ADDRESS
  value: {{ template "nms.dpm.service.natsStreaming" . }}
- name: NMS_INTEGRATIONS_ADDRESS
  value: {{ template "nms.integrations.service.http" . }}
- name: NMS_CORE_ADDRESS
  value: {{ template "nms.core.service.http" . }}
{{- end }}

{{/* Helper to return ingestion name */}}
{{- define "nms.ingestion.name" -}}
{{ .Values.ingestion.name | default "ingestion" }}
{{- end -}}

{{/* Helper to return ingestion http container bind address */}}
{{- define "nms.ingestion.httpAddress" -}}
0.0.0.0:{{ template "nms.ingestion.httpPort" . }}
{{- end -}}

{{/* Helper to return ingestion container http port */}}
{{- define "nms.ingestion.httpPort" -}}
{{ .Values.ingestion.container.port.http | default 8040 }}
{{- end -}}

{{/* Helper to return ingestion grpc container bind address */}}
{{- define "nms.ingestion.grpcAddress" -}}
0.0.0.0:{{ template "nms.ingestion.grpcPort" . }}
{{- end -}}

{{/* Helper to return ingestion container grpc port */}}
{{- define "nms.ingestion.grpcPort" -}}
{{ .Values.ingestion.container.port.grpc | default 8035 }}
{{- end -}}

{{/* Helper to return ingestion service grpc port */}}
{{- define "nms.ingestion.service.grpcPort" -}}
{{ .Values.ingestion.service.grpcPort | default 8035 }}
{{- end -}}

{{/* Helper to return ingestion grpc service */}}
{{- define "nms.ingestion.service.grpc" -}}
{{ template "nms.ingestion.name" . }}:{{ template "nms.ingestion.service.grpcPort" . }}
{{- end -}}

{{/* Helper to return ingestion service http port */}}
{{- define "nms.ingestion.service.httpPort" -}}
{{ .Values.ingestion.service.httpPort | default 8040 }}
{{- end -}}

{{/* Helper to return ingestion http service */}}
{{- define "nms.ingestion.service.http" -}}
{{ template "nms.ingestion.name" . }}:{{ template "nms.ingestion.service.httpPort" . }}
{{- end -}}

{{- define "nms.ingestion.selectorLabels" -}}
app.kubernetes.io/name: {{ template "nms.ingestion.name" . }}
{{- end }}

{{- define "nms.ingestion.podLabels" -}}
{{ include "nms.ingestion.selectorLabels" . }}
{{- with .Values.podLabels }}
{{ toYaml . }}
{{- end }}
{{- with .Values.ingestion.pod.labels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{*
   ------ Security Monitoring ------
*}

{{/* Helper to return secmon name */}}
{{- define "nms.secmon.name" -}}
{{ .Values.secmon.name | default "secmon" }}
{{- end -}}

{{/* ENV variables nms-secmon */}}
{{- define "nms.secmon.env" -}}
- name: NMS_DPM_NATS_ADDRESS
  value: {{ template "nms.dpm.service.natsStreaming" . }}
{{- end }}

{{- define "nms.secmon.selectorLabels" -}}
app.kubernetes.io/name: {{ template "nms.secmon.name" . }}
{{- end }}

{{- define "nms.secmon.podLabels" -}}
{{ include "nms.secmon.selectorLabels" . }}
{{- with .Values.podLabels }}
{{ toYaml . }}
{{- end }}
{{- with .Values.secmon.pod.labels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/* Helper to return secmon container http port */}}
{{- define "nms.secmon.httpPort" -}}
{{ .Values.secmon.container.port.http | default 8039 }}
{{- end -}}

{{/* Helper to return secmon service http port */}}
{{- define "nms.secmon.service.httpPort" -}}
{{ .Values.secmon.service.httpPort | default 8039 }}
{{- end -}}

{{/* Helper to return secmon service http */}}
{{- define "nms.secmon.service.http" -}}
{{ template "nms.secmon.name" . }}:{{ template "nms.secmon.service.httpPort" . }}
{{- end -}}

{{/* Helper to return secmon container bind address */}}
{{- define "nms.secmon.httpAddress" -}}
0.0.0.0:{{ template "nms.secmon.httpPort" . }}
{{- end -}}


{*
   ------ Integrations ------
*}

{{/* ENV variables used by nms-integrations */}}
{{- define "nms.integrations.env" -}}
- name: NMS_DPM_NATS_ADDRESS
  value: {{ template "nms.dpm.service.natsStreaming" . }}
- name: NMS_CORE_ADDRESS
  value: {{ template "nms.core.service.http" . }}
- name: NMS_CORE_DQLITE_ADDR
  value: {{ template "nms.core.service.dqlite" . }}
- name: NMS_DPM_ADDRESS
  value: {{ template "nms.dpm.service.http" . }}
{{- end }}

{{/* Helper to return Integrations http container bind address */}}
{{- define "nms.integrations.httpAddress" -}}
0.0.0.0:{{ template "nms.integrations.httpPort" . }}
{{- end -}}

{{/* Helper to return Integrations dqlite container bind address */}}
{{- define "nms.integrations.dqliteAddress" -}}
{{ "0.0.0.0" }}:{{ .Values.integrations.container.port.db | default 7892 }}
{{- end -}}

{{/* Helper to return Integrations license server dqlite container bind address */}}
{{- define "nms.integrations.license.dqliteAddress" -}}
{{ "0.0.0.0" }}:{{ .Values.integrations.container.port.licenseDB | default 7893 }}
{{- end -}}

{{/* Helper to return Integrations license mode of operation of instance */}}
{{- define "nms.integrations.license.modeOfOperation" -}}
{{ .Values.integrations.container.modeOfOperation | default "connected" }}
{{- end -}}

{{/* Helper to return integrations name */}}
{{- define "nms.integrations.name" -}}
{{ .Values.integrations.name | default "integrations" }}
{{- end -}}

{{/* Helper to return Integrations http service */}}
{{- define "nms.integrations.service.http" -}}
{{ template "nms.integrations.name" . }}:{{ template "nms.integrations.service.httpPort" . }}
{{- end -}}

{{/* Helper to return Integrations container http port */}}
{{- define "nms.integrations.httpPort" -}}
{{ .Values.integrations.container.port.http | default 8037 }}
{{- end -}}

{{/* Helper to return Integrations service http port */}}
{{- define "nms.integrations.service.httpPort" -}}
{{ .Values.integrations.service.httpPort | default 8037 }}
{{- end -}}

{{- define "nms.integrations.selectorLabels" -}}
app.kubernetes.io/name: {{ template "nms.integrations.name" . }}
{{- end }}

{{- define "nms.integrations.podLabels" -}}
{{ include "nms.integrations.selectorLabels" . }}
{{- with .Values.podLabels }}
{{ toYaml . }}
{{- end }}
{{- with .Values.integrations.pod.labels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/* Helper to get Integrations storage class for storage provisioning */}}
{{- define "nms.integrations.storageClass" -}}
{{- if .Values.integrations.persistence.storageClass }}
{{- if (eq "-" .Values.integrations.persistence.storageClass) }}
storageClassName: ""
{{- else }}
storageClassName: "{{ .Values.integrations.persistence.storageClass }}"
{{- end }}
{{- end }}
{{- end }}

{{- define "nms.integrations.userVolumes" -}}
{{- if .Values.integrations.persistence.enabled }}
{{- range .Values.integrations.persistence.claims }}
{{- if eq "dqlite" .name }}
- name: dqlite-volume
  persistentVolumeClaim:
    claimName: {{ .existingClaim | default ( printf "%s-%s" (include "nms.integrations.name" $ ) .name ) }}
{{- else if eq "proxy-certs" .name }}
- name: proxy-certs-volume
  persistentVolumeClaim:
    claimName: {{ .existingClaim | default (printf "%s-%s" (include "nms.integrations.name" $ ) .name) }}
{{- end -}}
{{- end -}}
{{- else }}
- name: dqlite-volume
  emptyDir: {}
- name: proxy-certs-volume
  emptyDir: {}
{{- end -}}
{{- end -}}

{{- define "nms.integrations.userVolumeMounts" -}}
- name: dqlite-volume
  mountPath: /var/lib/nms/dqlite
- name: proxy-certs-volume
  mountPath: /usr/local/share/ca-certificates
{{- end -}}

{*
   ------ Utility ------
*}

{{/* ENV variables */}}
{{- define "nms.utility.env" -}}
{{- end }}

{{/* Helper to return utility name */}}
{{- define "nms.utility.name" -}}
{{ .Values.utility.name | default "utility" }}
{{- end -}}

{{- define "nms.utility.selectorLabels" -}}
app.kubernetes.io/name: {{ template "nms.utility.name" . }}
{{- end }}

{{- define "nms.utility.userVolumes" -}}
{{- if .Values.core.persistence.enabled }}
- name: core-dqlite-volume
  persistentVolumeClaim:
    claimName: {{ template "nms.core.name" . }}-dqlite
- name: secrets-volume
  persistentVolumeClaim:
    claimName: {{ template "nms.core.name" . }}-secrets
{{- end }}
{{- if .Values.dpm.persistence.enabled }}
- name: dpm-dqlite-volume
  persistentVolumeClaim:
    claimName: {{ template "nms.dpm.name" . }}-dqlite
{{- end }}
{{- if .Values.integrations.persistence.enabled }}
- name: integrations-dqlite-volume
  persistentVolumeClaim:
    claimName: {{ template "nms.integrations.name" . }}-dqlite
{{- end }}
{{- range $k, $v := $.Values.global.nmsModules }}
{{- if $v.enabled }}
{{- if $v.addClaimsToUtility }}
{{- if eq "nms-acm" $k }}
- name: acm-dqlite-volume
  persistentVolumeClaim:
    claimName: acm-dqlite
{{- end }}
- name: {{ $k }}-conf-volume
  configMap:
    defaultMode: 0644
    name: {{ $k }}-conf
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{- define "nms.utility.userVolumeMounts" -}}
{{- if .Values.core.persistence.enabled }}
- name: core-dqlite-volume
  mountPath: /var/lib/nms/dqlite/core
- name: secrets-volume
  mountPath: /var/lib/nms/secrets
{{- end }}
{{- if .Values.dpm.persistence.enabled }}
- name: dpm-dqlite-volume
  mountPath: /var/lib/nms/dqlite/dpm
{{- end }}
{{- if .Values.integrations.persistence.enabled }}
- name: integrations-dqlite-volume
  mountPath: /var/lib/nms/dqlite/integrations
{{- end }}
{{- range $k, $v := $.Values.global.nmsModules }}
{{- if $v.enabled }}
{{- if $v.addClaimsToUtility }}
{{- if eq "nms-acm" $k }}
- name: acm-dqlite-volume
  mountPath: /var/lib/nms/dqlite/acm
- name: {{ $k }}-conf-volume
  mountPath: /etc/nms/acm.conf
  subPath: acm.conf
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{*
   ------ Logging ------
*}

{{/* Logging encoding type */}}
{{- define "nms.log.encoding" -}}
{{ .Values.log.encoding | default "console" }}
{{- end -}}

{{/* Logging level */}}
{{- define "nms.log.level" -}}
{{ .Values.log.level | default "error" }}
{{- end -}}

{{/* NIM Liveness Address for health checks */}}
{{- define "nms.nimLivenessAddress" -}}
{{ .Values.nimLivenessAddress | default "apigw" }}
{{- end -}}

{*
   ------ Proxy Config ------
*}

{{- define "nms.proxyConfig.proxyEnable" -}}
{{ .Values.proxyConfig.proxyEnable | default false }}
{{- end -}}

{{- define "nms.proxyConfig.proxyHost" -}}
{{ .Values.proxyConfig.proxyHost | default (printf "\"\"") }}
{{- end -}}

{{- define "nms.proxyConfig.proxyPort" -}}
{{ .Values.proxyConfig.proxyPort | default 3128 }}
{{- end -}}

{{- define "nms.proxyConfig.proxyProtocol" -}}
{{ .Values.proxyConfig.proxyProtocol | default "http" }}
{{- end -}}

{{- define "nms.proxyConfig.proxyAuthRequired" -}}
{{ .Values.proxyConfig.proxyAuthRequired | default false }}
{{- end -}}

{{- define "nms.proxyConfig.proxyUsername" -}}
{{ .Values.proxyConfig.proxyUsername | default (printf "\"\"") }}
{{- end -}}

{{- define "nms.proxyConfig.proxyPassword" -}}
{{ .Values.proxyConfig.proxyPassword | default (printf "\"\"") }}
{{- end -}}

{{- define "nms.proxyConfig.proxySslVerify" -}}
{{ .Values.proxyConfig.proxySslVerify | default true }}
{{- end -}}
