{{/*
Expand the name of the chart.
*/}}
{{- define "f5-waf-policy-controller.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "f5-waf-policy-controller.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "f5-waf-policy-controller.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "f5-waf-policy-controller.labels" -}}
helm.sh/chart: {{ include "f5-waf-policy-controller.chart" . }}
{{ include "f5-waf-policy-controller.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "f5-waf-policy-controller.selectorLabels" -}}
app.kubernetes.io/name: {{ include "f5-waf-policy-controller.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
F5 WAF component naming (for Policy Controller, Compiler, SeaweedFS)
*/}}

{{/*
F5 WAF fullname - used for Policy Controller ecosystem components
*/}}
{{- define "f5-waf.fullname" -}}
{{- printf "%s-f5-waf" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
F5 WAF namespace - used for Policy Controller ecosystem components
*/}}
{{- define "f5-waf.namespace" -}}
{{- .Values.namespace | default .Release.Namespace }}
{{- end }}

{{/*
S3 HTTPS port for SeaweedFS.
*/}}
{{- define "f5-waf.s3httpsPort" -}}
{{- if .Values.seaweedfsOperatorConfig.seaweedfs.certificates.enabled }}
{{- .Values.seaweedfsOperatorConfig.seaweedfs.filerS3HttpsPort | default 9333 | int }}
{{- else }}
{{- 0 | int }}
{{- end }}
{{- end }}

{{/*
S3 endpoint for SeaweedFS.
Auto-calculates based on release name and namespace if not explicitly set.
Supports both HTTP and HTTPS based on configuration.
*/}}
{{- define "f5-waf.s3Endpoint" -}}
{{- if .Values.policyController.s3Endpoint }}
{{- .Values.policyController.s3Endpoint }}
{{- else if .Values.seaweedfsOperatorConfig.seaweedfs.certificates.enabled }}
{{- printf "https://%s-seaweed-filer.%s.svc.cluster.local:%d" (include "f5-waf.fullname" .) (include "f5-waf.namespace" .) (include "f5-waf.s3httpsPort" . | int) }}
{{- else }}
{{- printf "http://%s-seaweed-filer.%s.svc.cluster.local:%d" (include "f5-waf.fullname" .) (include "f5-waf.namespace" .) (.Values.seaweedfsOperatorConfig.seaweedfs.filer.filerS3Port | default 8333 | int)}}
{{- end }}
{{- end }}

{{- /* Defensive only: other templates still require a populated compiler map. */ -}}
{{- define "f5-waf.compilerAutoscalingEnabled" -}}
{{- $compiler := default dict .Values.compiler -}}
{{- $autoscaling := default dict (index $compiler "autoscaling") -}}
{{- $enabled := index $autoscaling "enabled" -}}
{{- if or (kindIs "invalid" $enabled) (eq (toString $enabled) "") -}}
false
{{- else if eq (lower (toString $enabled)) "true" -}}
true
{{- else if eq (lower (toString $enabled)) "false" -}}
false
{{- else -}}
{{- fail "compiler.autoscaling.enabled must be true or false" -}}
{{- end -}}
{{- end }}

{{- define "f5-waf.validateCompilerCPURequest" -}}
{{- $cpuRequestStr := trim (toString .) -}}
{{- $validMilli := regexMatch "^[+]?[0-9]+m$" $cpuRequestStr -}}
{{- $validCores := regexMatch "^[+]?(?:[0-9]+(?:\\.[0-9]{0,3})?|\\.[0-9]{1,3})$" $cpuRequestStr -}}
{{- /* Negative exponents below -3 would be sub-millicore, so stop at 1e-3 == 1m. */ -}}
{{- $validScientific := regexMatch "^[+]?[0-9]+(?:[eE][+]?[0-9]+|[eE]-[0-3])$" $cpuRequestStr -}}
{{- if not (or $validMilli $validCores $validScientific) -}}
{{- fail "compiler.resources.requests.cpu must be a supported positive CPU quantity with no finer than 1m precision when compiler.autoscaling.enabled=true because CPU utilization is calculated relative to the CPU request" -}}
{{- end -}}
{{- $mantissa := regexReplaceAll "m$|[eE][+-]?[0-9]+$" $cpuRequestStr "" -}}
{{- if not (regexMatch "[1-9]" $mantissa) -}}
{{- fail "compiler.resources.requests.cpu must be > 0 when compiler.autoscaling.enabled=true because CPU utilization is calculated relative to the CPU request" -}}
{{- end -}}
{{- end }}

{{- define "f5-waf.validateCompilerAutoscaling" -}}
{{- if eq (include "f5-waf.compilerAutoscalingEnabled" .) "true" -}}
{{- $compiler := default dict .Values.compiler -}}
{{- $autoscaling := default dict (index $compiler "autoscaling") -}}
{{- $resources := default dict (index $compiler "resources") -}}
{{- $requests := default dict (index $resources "requests") -}}
{{- $cpuRequest := index $requests "cpu" -}}
{{- if or (kindIs "invalid" $cpuRequest) (eq (toString $cpuRequest) "") -}}
{{- fail "compiler.resources.requests.cpu must be set when compiler.autoscaling.enabled=true because CPU utilization is calculated relative to the CPU request" -}}
{{- end -}}
{{- include "f5-waf.validateCompilerCPURequest" $cpuRequest -}}
{{- $minReplicasRaw := index $autoscaling "minReplicas" -}}
{{- if or (kindIs "invalid" $minReplicasRaw) (eq (toString $minReplicasRaw) "") -}}
{{- fail "compiler.autoscaling.minReplicas must be set when compiler.autoscaling.enabled=true" -}}
{{- end -}}
{{- $minReplicas := int $minReplicasRaw -}}
{{- if lt $minReplicas 1 -}}
{{- fail "compiler.autoscaling.minReplicas must be >= 1" -}}
{{- end -}}
{{- $maxReplicasRaw := index $autoscaling "maxReplicas" -}}
{{- if or (kindIs "invalid" $maxReplicasRaw) (eq (toString $maxReplicasRaw) "") -}}
{{- fail "compiler.autoscaling.maxReplicas must be set when compiler.autoscaling.enabled=true" -}}
{{- end -}}
{{- $maxReplicas := int $maxReplicasRaw -}}
{{- if lt $maxReplicas $minReplicas -}}
{{- fail "compiler.autoscaling.maxReplicas must be >= compiler.autoscaling.minReplicas" -}}
{{- end -}}
{{- $targetCPUUtilizationPercentageRaw := index $autoscaling "targetCPUUtilizationPercentage" -}}
{{- if or (kindIs "invalid" $targetCPUUtilizationPercentageRaw) (eq (toString $targetCPUUtilizationPercentageRaw) "") -}}
{{- fail "compiler.autoscaling.targetCPUUtilizationPercentage must be set when compiler.autoscaling.enabled=true" -}}
{{- end -}}
{{- $targetCPUUtilizationPercentage := int $targetCPUUtilizationPercentageRaw -}}
{{- if lt $targetCPUUtilizationPercentage 1 -}}
{{- fail "compiler.autoscaling.targetCPUUtilizationPercentage must be >= 1" -}}
{{- end -}}
{{- end -}}
{{- end }}

{{- define "f5-waf.validateCompilerCapacity" -}}
{{- include "f5-waf.validateCompilerAutoscaling" . -}}
{{- $compiler := default dict .Values.compiler -}}
{{- $policyController := default dict .Values.policyController -}}
{{- $autoscaling := default dict (index $compiler "autoscaling") -}}
{{- $autoscalingEnabled := eq (include "f5-waf.compilerAutoscalingEnabled" .) "true" -}}
{{- $replicasRaw := index $compiler "replicas" -}}
{{- if and (not $autoscalingEnabled) (not (kindIs "invalid" $replicasRaw)) (ne (toString $replicasRaw) "") (lt (int $replicasRaw) 1) -}}
{{- fail "compiler.replicas=0 is not a supported pause configuration when autoscaling is disabled: the chart's default controller dependency wait expects compiler endpoints before startup and the controller cannot compile without a running compiler" -}}
{{- end -}}
{{- /* Skip capacity validation when either capacity input is unset or unknown. */ -}}
{{- $maxConcurrentSet := and (hasKey $compiler "maxConcurrent") (not (kindIs "invalid" (index $compiler "maxConcurrent"))) (ne (toString (index $compiler "maxConcurrent")) "") -}}
{{- $dispatchSet := and (hasKey $policyController "maxConcurrentCompilations") (not (kindIs "invalid" (index $policyController "maxConcurrentCompilations"))) (ne (toString (index $policyController "maxConcurrentCompilations")) "") -}}
{{- if and $maxConcurrentSet $dispatchSet -}}
{{- $effectiveReplicasRaw := index $compiler "replicas" -}}
{{- if or (kindIs "invalid" $effectiveReplicasRaw) (eq (toString $effectiveReplicasRaw) "") -}}
{{- $effectiveReplicasRaw = 1 -}}
{{- end -}}
{{- if $autoscalingEnabled -}}
{{- $effectiveReplicasRaw = index $autoscaling "maxReplicas" -}}
{{- end -}}
{{- $maxConcurrent := int (index $compiler "maxConcurrent") -}}
{{- $configuredDispatch := int (index $policyController "maxConcurrentCompilations") -}}
{{- $effectiveReplicas := int $effectiveReplicasRaw -}}
{{- $capacity := mul $maxConcurrent $effectiveReplicas -}}
{{- if gt $configuredDispatch $capacity -}}
{{- fail (printf "configured policyController.maxConcurrentCompilations=%d exceeds computed compiler capacity=%d (compiler.maxConcurrent=%d * effectiveCompilerReplicas=%d); lower policyController.maxConcurrentCompilations or increase compiler capacity" $configuredDispatch $capacity $maxConcurrent $effectiveReplicas) -}}
{{- end -}}
{{- end -}}
{{- end }}
