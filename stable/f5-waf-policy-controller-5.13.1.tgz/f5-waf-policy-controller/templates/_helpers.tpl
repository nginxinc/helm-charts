{{/*
Expand the name of the chart.
*/}}
{{- define "f5-waf-policy-controller.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "f5-waf-policy-controller.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "f5-waf-policy-controller.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "f5-waf-policy-controller.labels" -}}
helm.sh/chart: {{ include "f5-waf-policy-controller.chart" . }}
{{ include "f5-waf-policy-controller.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "f5-waf-policy-controller.selectorLabels" -}}
app.kubernetes.io/name: {{ include "f5-waf-policy-controller.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
F5 WAF component naming (for Policy Controller, Compiler, Redis, SeaweedFS)
*/}}

{{/*
F5 WAF fullname - used for Policy Controller ecosystem components
*/}}
{{- define "f5-waf.fullname" -}}
{{- printf "%s-f5-waf" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
F5 WAF namespace - used for Policy Controller ecosystem components
*/}}
{{- define "f5-waf.namespace" -}}
{{- .Values.namespace | default .Release.Namespace }}
{{- end }}

{{/*
S3 HTTPS port for SeaweedFS.
*/}}
{{- define "f5-waf.s3httpsPort" -}}
{{- if .Values.seaweedfsOperatorConfig.seaweedfs.certificates.enabled }}
{{- .Values.seaweedfsOperatorConfig.seaweedfs.filerS3HttpsPort | default 9333 | int }}
{{- else }}
{{- 0 | int }}
{{- end }}
{{- end }}

{{/*
S3 endpoint for SeaweedFS.
Auto-calculates based on release name and namespace if not explicitly set.
Supports both HTTP and HTTPS based on configuration.
*/}}
{{- define "f5-waf.s3Endpoint" -}}
{{- if .Values.policyController.s3Endpoint }}
{{- .Values.policyController.s3Endpoint }}
{{- else if .Values.seaweedfsOperatorConfig.seaweedfs.certificates.enabled }}
{{- printf "https://%s-seaweed-filer.%s.svc.cluster.local:%d" (include "f5-waf.fullname" .) (include "f5-waf.namespace" .) (include "f5-waf.s3httpsPort" . | int) }}
{{- else }}
{{- printf "http://%s-seaweed-filer.%s.svc.cluster.local:%d" (include "f5-waf.fullname" .) (include "f5-waf.namespace" .) (.Values.seaweedfsOperatorConfig.seaweedfs.filer.filerS3Port | default 8333 | int)}}
{{- end }}
{{- end }}
